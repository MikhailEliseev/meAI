# Session: 2026-06-28 — HeadroomGuard Integration Complete

## Текущий фокус

**HeadroomGuard развёрнут и активен**

**Что сделано:**
- ✅ HeadroomGuard sidecar контейнер запущен (aim-headroom-proxy)
- ✅ Hermes переключён на прокси: `OMNIROUTE_URL=http://headroom-proxy:8787/v1`
- ✅ Интеграция через docker-compose.headroom.yml
- ✅ Backup оригинальной конфигурации сохранён
- ✅ Оба контейнера healthy

**Архитектура:**
```
Next.js → FastAPI → Hermes → HeadroomGuard (8787) → z.ai API (glm-5)
                                  ↓
                            компрессия 60-95%
                            SOUL.md 104KB: ~40k → ~8k токенов
```

**Конфигурация:**
- `HEADROOM_UPSTREAM_URL=https://api.z.ai/api/coding/paas/v4`
- `HEADROOM_COMPRESS_TOOLS=false` (сохраняет tool calling)
- `HEADROOM_KEEP_TURNS=2` (всегда сохранять последние 2 сообщения)
- `HEADROOM_MODE=optimize` (активная компрессия)

**Что нужно протестировать:**
1. Отправить тестовый URL клиники через iamaim.ru
2. Проверить логи HeadroomGuard: `docker logs aim-headroom-proxy -f`
3. Проверить метрики: `curl http://localhost:8787/stats`
4. Убедиться что отчёт генерируется корректно
5. Замерить компрессию (ожидаем 60-95% экономии)

**Rollback план:**
```bash
cd /opt/aim/AIM
docker compose -f docker-compose.yml -f docker-compose.headroom.yml stop headroom-proxy
docker compose down hermes
docker compose up -d hermes
# Hermes вернётся к OMNIROUTE_URL=https://api.z.ai/api/coding/paas/v4
```

**DeepSeek fallback:** Пока НЕ используется. HeadroomGuard только компрессирует, не выбирает провайдера. Для fallback нужен отдельный роутер (LiteLLM или самописный).

---

## Предыдущая работа (2026-06-27)

### WordPress Golden Master бэкап

**Создан эталонный бэкап WordPress темы:**
- `AIM/wp-golden-master.tar.gz` (8.5 MB)
- `AIM/WP-GOLDEN-MASTER-README.md` — документация
- Содержит reference дизайн: `design-showcase-dual-theme.html` (102 KB)
- Все чат компоненты, assets, theme.css

### Auto-commit система

**Добавлена защита от потери незакоммиченных изменений:**
- `scripts/auto-commit-deploy.sh` — автокоммит перед деплоем
- `.git/hooks/pre-push` — автокоммит перед push
- CLAUDE.md обновлён с правилом Auto-Commit Before Deploy

### Phase 09 откат

**Откат сервера на 2 дня назад:**
- Причина: потеря HeadroomGuard обёртки (не закоммичена, не забэкаплена)
- Phase 09 полностью сохранена: `~/Desktop/phase09-COMPLETE-20260628-022838.tar.gz` (446 KB)
- SOUL.md восстановлен: 104 KB, 1410 строк, 25 июня 22:21
- Hermes app/ файлы: версия от 25 июня (до Phase 09)

---

## План интеграции HeadroomGuard (выполнен)

### Phase 1: Docker Sidecar (✅ DONE)

- [x] Docker-compose конфигурация создана
- [x] Образ скачан: `ghcr.io/chopratejas/headroom:latest`
- [x] Контейнер запущен на порту 8787
- [x] Hermes переключён на прокси
- [x] Healthcheck работает

### Phase 2: Testing (⏳ IN PROGRESS)

- [ ] Тест через iamaim.ru чат
- [ ] Проверка метрик компрессии
- [ ] Валидация качества отчётов
- [ ] Измерение латенси
- [ ] Мониторинг 24 часа

### Phase 3: DeepSeek Fallback (BACKLOG)

HeadroomGuard не умеет fallback между провайдерами. Опции:
1. LiteLLM Router в agent_wrapper.py
2. Portkey как отдельный sidecar
3. Самописный if/else с try/except

---

## Текущая конфигурация production

```yaml
HeadroomGuard:
  container: aim-headroom-proxy
  port: 8787
  upstream: https://api.z.ai/api/coding/paas/v4
  mode: optimize
  compress_tools: false
  keep_turns: 2

Hermes:
  container: aim-hermes
  OMNIROUTE_URL: http://headroom-proxy:8787/v1
  LLM_MODEL: glm-5
  OMNIROUTE_AUTH: 6fd916373bd7462499481201277a7ad0.aCqG4YQTsePka6tI

SOUL.md: 104KB (1410 строк)
AIM tools: 33 зарегистрировано
```

## Файлы интеграции

- `AIM/docker-compose.headroom.yml` — sidecar конфигурация
- `AIM/hermes/HEADROOM-INTEGRATION-PLAN.md` — архитектура и фазы
- `AIM/hermes/HEADROOM-DEPLOY.md` — пошаговый деплой
- `/opt/aim/AIM/.env.headroom` — переменные окружения на сервере

## Commits

- `1af0506` — HeadroomGuard integration prep (28 июня 03:11)

## Что НЕ делать

- ❌ Менять `HEADROOM_COMPRESS_TOOLS` на true (сломает tool calling)
- ❌ Удалять HeadroomGuard без тестирования rollback плана
- ❌ Деплоить без backup текущей конфигурации
