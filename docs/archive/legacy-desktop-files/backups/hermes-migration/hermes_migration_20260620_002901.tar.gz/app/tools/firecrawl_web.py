"""
firecrawl_web — Hermes tools: Firecrawl-powered web scraping, search, crawl, map.

Part of toolset "hermes-debug". Uses FirecrawlKeyBank for multi-key rotation
with automatic fallback on 402/credit-exhaustion errors.

Keys loaded from FIRECRAWL_KEYS_FILE (default: /opt/data/firecrawl_keys.json).
Falls back to FIRECRAWL_API_KEY env var if no bank file.
"""

import json
import logging
import os
import threading

from tools.registry import registry
from .firecrawl_key_bank import get_next_key, mark_exhausted, classify_exhaustion, active_count

logger = logging.getLogger(__name__)

_FALLBACK_KEY = os.environ.get("FIRECRAWL_API_KEY", "").strip()
_lock = threading.Lock()


def _get_client():
    """Create a Firecrawl client using the next available key from the bank."""
    from firecrawl import Firecrawl

    try:
        key = get_next_key()
    except RuntimeError:
        if _FALLBACK_KEY:
            return Firecrawl(api_key=_FALLBACK_KEY), _FALLBACK_KEY
        raise
    return Firecrawl(api_key=key), key


def _handle_credit_error(key: str, error_msg: str):
    """Mark key dead on credit exhaustion and rotate."""
    if not key:
        return
    reason = classify_exhaustion(error_msg)
    if not reason:
        return
    try:
        mark_exhausted(key, reason)
    except Exception:
        pass


async def handle_firecrawl_scrape(url=None, formats=None, only_main_content=None, **kwargs) -> str:
    if isinstance(url, dict):
        d = url
        url = d.get("url", "")
        formats = d.get("formats", formats)
        only_main_content = d.get("only_main_content", only_main_content)

    if not url:
        return json.dumps({"error": "url is required"})

    fmts = formats if formats else ["markdown"]
    main_only = only_main_content if only_main_content is not None else True

    for attempt in range(3):
        try:
            fc, key = _get_client()
        except RuntimeError:
            return json.dumps({"error": "FIRECRAWL_API_KEY not set and no keys in bank"})

        logger.info("firecrawl_scrape: %s (attempt %d)", url[:120], attempt + 1)
        try:
            result = fc.scrape(url, formats=fmts, only_main_content=main_only)
            return json.dumps({
                "url": url,
                "title": result.get("metadata", {}).get("title", ""),
                "markdown": result.get("markdown", "")[:50000],
                "metadata": result.get("metadata", {}),
                "actions": result.get("actions", {}),
            }, ensure_ascii=False)
        except Exception as e:
            err = str(e)
            _handle_credit_error(key, err)
            if not classify_exhaustion(err):
                logger.error("firecrawl_scrape failed: %s", err[:200])
                return json.dumps({"error": err[:500]})

    return json.dumps({"error": "firecrawl_scrape: all keys exhausted"})


async def handle_firecrawl_search(query=None, limit=None, source=None, **kwargs) -> str:
    if isinstance(query, dict):
        d = query
        query = d.get("query", "")
        limit = d.get("limit", limit)
        source = d.get("source", source)

    if not query:
        return json.dumps({"error": "query is required"})

    max_results = int(limit) if limit else 5
    src = source if source else "web"

    for attempt in range(3):
        try:
            fc, key = _get_client()
        except RuntimeError:
            return json.dumps({"error": "FIRECRAWL_API_KEY not set and no keys in bank"})

        logger.info("firecrawl_search: %s (limit=%d, source=%s, attempt=%d)", query[:80], max_results, src, attempt + 1)
        try:
            result = fc.search(query, limit=max_results, source=src)
            results = []
            for r in result.get("data", [])[:max_results]:
                results.append({
                    "title": r.get("title", ""),
                    "url": r.get("url", ""),
                    "description": r.get("description", ""),
                    "markdown": r.get("markdown", "")[:10000],
                })

            return json.dumps({
                "query": query,
                "source": src,
                "results_count": len(results),
                "results": results,
            }, ensure_ascii=False)
        except Exception as e:
            err = str(e)
            _handle_credit_error(key, err)
            if not classify_exhaustion(err):
                logger.warning("firecrawl_search failed: %s", err[:200])
                return json.dumps({
                    "query": query, "source": "error",
                    "results_count": 0, "results": [],
                    "error": "search unavailable",
                })

    return json.dumps({
        "query": query, "source": "error",
        "results_count": 0, "results": [],
        "error": "all FireCrawl keys exhausted",
    })


async def handle_firecrawl_crawl(url=None, limit=None, max_pages=None, **kwargs) -> str:
    if isinstance(url, dict):
        d = url
        url = d.get("url", "")
        limit = d.get("limit", d.get("max_pages", limit))

    if not url:
        return json.dumps({"error": "url is required"})

    max_pages_val = int(limit) if limit else 10

    for attempt in range(3):
        try:
            fc, key = _get_client()
        except RuntimeError:
            return json.dumps({"error": "FIRECRAWL_API_KEY not set and no keys in bank"})

        logger.info("firecrawl_crawl: %s (max_pages=%d, attempt=%d)", url[:120], max_pages_val, attempt + 1)
        try:
            result = fc.crawl(url, limit=max_pages_val, scrape_options={"formats": ["markdown"]})
            pages = []
            for p in result.get("data", [])[:max_pages_val]:
                pages.append({
                    "url": p.get("metadata", {}).get("url", ""),
                    "title": p.get("metadata", {}).get("title", ""),
                    "markdown": (p.get("markdown", "") or "")[:20000],
                })

            return json.dumps({
                "start_url": url,
                "total_pages": len(pages),
                "pages": pages,
            }, ensure_ascii=False)
        except Exception as e:
            err = str(e)
            _handle_credit_error(key, err)
            if not classify_exhaustion(err):
                logger.error("firecrawl_crawl failed: %s", err[:200])
                return json.dumps({"error": err[:500]})

    return json.dumps({"error": "firecrawl_crawl: all keys exhausted"})


async def handle_firecrawl_map(url=None, **kwargs) -> str:
    if isinstance(url, dict):
        d = url
        url = d.get("url", "")

    if not url:
        return json.dumps({"error": "url is required"})

    for attempt in range(3):
        try:
            fc, key = _get_client()
        except RuntimeError:
            return json.dumps({"error": "FIRECRAWL_API_KEY not set and no keys in bank"})

        logger.info("firecrawl_map: %s (attempt=%d)", url[:120], attempt + 1)
        try:
            result = fc.map(url)
            urls = result.get("links", [])
            return json.dumps({
                "url": url,
                "total_urls": len(urls),
                "urls": urls[:500],
            }, ensure_ascii=False)
        except Exception as e:
            err = str(e)
            _handle_credit_error(key, err)
            if not classify_exhaustion(err):
                logger.error("firecrawl_map failed: %s", err[:200])
                return json.dumps({"error": err[:500]})

    return json.dumps({"error": "firecrawl_map: all keys exhausted"})


# ── Register tools ──────────────────────────────────────────────────

def _check():
    try:
        return active_count > 0 or bool(_FALLBACK_KEY)
    except Exception:
        return bool(_FALLBACK_KEY)


registry.register(
    name="firecrawl_scrape",
    toolset="hermes-debug",
    schema={
        "type": "function",
        "function": {
            "name": "firecrawl_scrape",
            "description": (
                "Scrape a single URL and return clean markdown via Firecrawl. "
                "Handles JavaScript-rendered pages, bypasses anti-bot protection. "
                "Returns title, markdown content, metadata, and available actions. "
                "Use for: reading competitor pages, extracting pricing, analyzing content."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "[REQUIRED] Full URL to scrape (https://...)",
                    },
                    "formats": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Output formats: markdown, html, screenshot (default: ['markdown'])",
                    },
                    "only_main_content": {
                        "type": "boolean",
                        "description": "Extract only main content, skip nav/footer (default: true)",
                    },
                },
                "required": ["url"],
            },
        },
    },
    handler=handle_firecrawl_scrape,
    check_fn=_check,
    is_async=True,
    description="Scrape URLs to clean markdown via Firecrawl",
    emoji="🔥",
)

registry.register(
    name="firecrawl_search",
    toolset="hermes-debug",
    schema={
        "type": "function",
        "function": {
            "name": "firecrawl_search",
            "description": (
                "Search the web via Firecrawl and return results with full page content. "
                "Better than simple search — returns markdown of each result page. "
                "Use for: finding competitors, researching topics, discovering tools. "
                "Source can be 'web' (default), 'news', or 'images'."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "[REQUIRED] Search query string",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results (default: 5)",
                    },
                    "source": {
                        "type": "string",
                        "enum": ["web", "news", "images"],
                        "description": "Search source (default: web)",
                    },
                },
                "required": ["query"],
            },
        },
    },
    handler=handle_firecrawl_search,
    check_fn=_check,
    is_async=True,
    description="Search web with page content via Firecrawl",
    emoji="🔎",
)

registry.register(
    name="firecrawl_crawl",
    toolset="hermes-debug",
    schema={
        "type": "function",
        "function": {
            "name": "firecrawl_crawl",
            "description": (
                "Crawl multiple pages from a domain and return combined markdown. "
                "Follows internal links, extracts content from each page. "
                "Use for: full site analysis, content inventory, competitor research."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "[REQUIRED] Starting URL for crawl (https://...)",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max pages to crawl (default: 10)",
                    },
                },
                "required": ["url"],
            },
        },
    },
    handler=handle_firecrawl_crawl,
    check_fn=_check,
    is_async=True,
    description="Crawl multiple pages via Firecrawl",
    emoji="🕷️",
)

registry.register(
    name="firecrawl_map",
    toolset="hermes-debug",
    schema={
        "type": "function",
        "function": {
            "name": "firecrawl_map",
            "description": (
                "Discover all URLs on a website without scraping content. "
                "Fast and lightweight — returns URL list only. "
                "Use for: sitemap discovery, site structure analysis, finding all pages."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "[REQUIRED] Website URL to map (https://...)",
                    },
                },
                "required": ["url"],
            },
        },
    },
    handler=handle_firecrawl_map,
    check_fn=_check,
    is_async=True,
    description="Discover all URLs on a site via Firecrawl",
    emoji="🗺️",
)
