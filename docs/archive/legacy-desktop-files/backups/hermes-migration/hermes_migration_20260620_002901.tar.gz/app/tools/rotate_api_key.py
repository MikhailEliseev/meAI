"""
rotate_api_key — Hermes tool: runtime API key rotation on failure.

When a Firecrawl or Apify tool returns "insufficient credits" / 402 / 401,
Hermes calls rotate_api_key to switch to the next valid key, then retries.

Part of toolset "aim-operations" — always available in presale/onboarding.
"""

import asyncio
import json
import logging
import os
import subprocess
import sys

from tools.registry import registry

logger = logging.getLogger(__name__)

ROTATE_SCRIPT = "/opt/data/scripts/rotate_keys.py"
SCRIPT_TIMEOUT = 30  # seconds per rotation attempt


def _find_working_key(service: str) -> dict:
    """Run rotate_keys.py --switch to find next working key."""
    try:
        proc = subprocess.run(
            [sys.executable, ROTATE_SCRIPT, "--switch", service],
            capture_output=True, text=True, timeout=SCRIPT_TIMEOUT,
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
        output = proc.stdout.strip() + proc.stderr.strip()
        return {
            "success": "Rotated" in output and "✅" in output,
            "service": service,
            "output": output[-500:],
            "exit_code": proc.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "service": service, "output": "timeout after 30s", "exit_code": -1}
    except FileNotFoundError:
        return {"success": False, "service": service, "output": f"Script not found: {ROTATE_SCRIPT}", "exit_code": -1}
    except Exception as e:
        return {"success": False, "service": service, "output": str(e)[:200], "exit_code": -1}


async def handle_rotate_api_key(service=None, **kwargs) -> str:
    """Rotate to the next valid API key for a service.

    Call this when a Firecrawl or Apify tool fails with:
    - "Insufficient credits"
    - "402 Payment Required"  
    - "401 Unauthorized"
    - "exhausted"

    The rotation script skips exhausted/invalid keys and picks the next working one.
    After rotation, config.yaml is synced automatically.

    Args:
        service: "firecrawl" or "apify"

    Returns:
        JSON with rotation result.
    """
    if isinstance(service, dict):
        service = service.get("service", "")

    service = (service or "").strip().lower()
    if service in ("fc", "firecrawl"):
        service = "firecrawl"
    elif service in ("apify", "ap"):
        service = "apify"
    
    if service not in ("firecrawl", "apify"):
        return json.dumps({
            "error": f"Unknown service: {service}. Use 'firecrawl' or 'apify'.",
        })

    logger.info("rotate_api_key: rotating %s key…", service)

    result = await asyncio.get_running_loop().run_in_executor(
        None, _find_working_key, service,
    )

    if result["success"]:
        logger.info("rotate_api_key: %s key rotated successfully", service)
    else:
        logger.error("rotate_api_key: %s rotation failed — %s", service, result["output"][:120])

    return json.dumps(result, ensure_ascii=False, indent=2)


# ── Registry ───────────────────────────────────────────────────────────────

registry.register(
    name="rotate_api_key",
    toolset="aim-operations",
    schema={
        "type": "function",
        "function": {
            "name": "rotate_api_key",
            "description": (
                "Rotate to the next valid API key for Apify or Firecrawl. " 
                "Call this when a Firecrawl/Apify tool fails with 'Insufficient credits', " 
                "402, 401, or 'exhausted'. The rotation script skips bad keys and picks " 
                "the next working one. config.yaml is synced automatically. " 
                "After rotation, RETRY the failed tool — it should work with the new key."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "service": {
                        "type": "string",
                        "description": "Service to rotate: 'firecrawl' (or 'fc') or 'apify' (or 'ap')",
                    },
                },
                "required": ["service"],
            },
        },
    },
    handler=handle_rotate_api_key,
    check_fn=lambda: os.path.exists(ROTATE_SCRIPT),
    is_async=True,
    description="Rotate API key on failure — switch to next valid key for Firecrawl or Apify",
    emoji="🔑",
)
