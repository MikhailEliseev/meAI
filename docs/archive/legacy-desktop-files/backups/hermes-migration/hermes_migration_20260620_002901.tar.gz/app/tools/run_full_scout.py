"""
run_full_scout — Complete scout pipeline: ALL tools → session archive → HTML report.

Calls every AIM tool in sequence, saves each result to
/opt/data/sessions-archive/{session_hash}/, then generates the
fully-populated HTML report.

Target: 45-75 minutes for complete scan.
Registered in Hermes internal registry under toolset "aim-operations".
"""

import asyncio
import json
import logging
import os
import time
from datetime import datetime, timezone

from tools.registry import registry

logger = logging.getLogger(__name__)

SESSIONS_ROOT = os.getenv("SESSIONS_ROOT", "/opt/data/sessions-archive")

# ── Pipeline phases ─────────────────────────────────────────────────────
# Each phase: (name, tool_handler, kwargs_builder, archive_key)
# kwargs_builder receives (url, company_name, city, instagram, preset_data)
# and returns the kwargs dict for the handler.


async def _run_phase(name: str, handler, kwargs: dict, session_hash: str, archive_key: str) -> dict | None:
    """Run a single phase, save output, return parsed result."""
    from app.main import push_tool_progress

    push_tool_progress("full-scout", f"Запуск: {name}…")
    t0 = time.time()
    try:
        result_str = await handler(**kwargs)
        elapsed = time.time() - t0
        result = json.loads(result_str) if isinstance(result_str, str) else result_str

        if result and not result.get("error"):
            from .session_archive import save_tool_output
            save_tool_output(session_hash, archive_key, result)
            push_tool_progress("full-scout", f"✓ {name} ({elapsed:.0f}s)")
        else:
            err = result.get("error", "empty result") if isinstance(result, dict) else "parse error"
            push_tool_progress("full-scout", f"⚠ {name}: {err} ({elapsed:.0f}s)")

        return result
    except Exception as e:
        elapsed = time.time() - t0
        logger.exception("Phase %s failed", name)
        push_tool_progress("full-scout", f"✗ {name}: {str(e)[:80]} ({elapsed:.0f}s)")
        return None


async def handle_run_full_scout(
    url=None,
    company_name=None,
    city=None,
    instagram=None,
    session_hash=None,
    deep=False,
    **kwargs,
) -> str:
    """Run the complete AIM scout pipeline — every tool, all data saved.

    Args:
        url: Clinic website URL (e.g. https://nachalo-clinica.ru)
        company_name: Clinic name (e.g. "Семейная клиника Начало")
        city: City for geo-targeting (e.g. "Ростов-на-Дону")
        instagram: Optional Instagram handle
        session_hash: Session archive key (default: derived from URL)
        deep: If True, run deep CI pass (slower but more thorough)

    Returns:
        JSON with session_hash, report_url, and phase summary.
    """
    if not url:
        return json.dumps({"error": "url is required"})
    if not company_name:
        return json.dumps({"error": "company_name is required"})

    # Derive session_hash from URL if not given
    if not session_hash:
        import re
        session_hash = re.sub(r"https?://(www\.)?", "", url)
        session_hash = re.sub(r"[^a-z0-9\-]", "", session_hash.lower())[:30]

    from app.main import push_tool_progress
    from .session_archive import upsert_metadata, save_tool_output

    # ── Metadata ─────────────────────────────────────────────────────
    upsert_metadata(
        session_hash,
        client_name=company_name,
        client_url=url,
        city=city or "",
        scan_type="full-scout",
        scan_started=datetime.now(timezone.utc).isoformat(),
    )
    push_tool_progress("full-scout", f"🚀 Полный скаут: {company_name}")

    all_phases = []

    # ═════════════════════════════════════════════════════════════════
    # Phase 1: PRESCAN (3 stages — tech, SEO, financials, social, etc.)
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_prescan import handle_run_prescan
    except ImportError:
        handle_run_prescan = None

    if handle_run_prescan:
        prescan = await _run_phase(
            "Prescan (Stage 1-3)", handle_run_prescan,
            {"url": url},
            session_hash, "prescan-data",
        )
        all_phases.append(("prescan", bool(prescan and not prescan.get("error"))))
    else:
        all_phases.append(("prescan", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 2: FIND COMPETITORS (Apify Google Maps scraper)
    # ═════════════════════════════════════════════════════════════════
    try:
        from .find_competitors import handle_find_competitors
    except ImportError:
        handle_find_competitors = None

    competitors_raw = None
    if handle_find_competitors:
        competitors_raw = await _run_phase(
            "Find Competitors", handle_find_competitors,
            {"url": url, "city": city, "company_name": company_name},
            session_hash, "competitors",
        )
        all_phases.append(("competitors", bool(competitors_raw and not competitors_raw.get("error"))))
    else:
        all_phases.append(("competitors", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 3: CI ANALYSIS (deep competitor intelligence)
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_ci_analysis import handle_run_ci_analysis
    except ImportError:
        handle_run_ci_analysis = None

    if handle_run_ci_analysis:
        ci_kwargs = {
            "url": url,
            "city": city,
            "deep": deep,
        }
        # Pass competitors to CI if we have them
        if competitors_raw and isinstance(competitors_raw, dict):
            comp_list = competitors_raw.get("competitors", [])
            if comp_list:
                ci_kwargs["competitors"] = comp_list

        await _run_phase(
            "CI Analysis", handle_run_ci_analysis,
            ci_kwargs,
            session_hash, "ci-analysis",
        )
        all_phases.append(("ci_analysis", True))
    else:
        all_phases.append(("ci_analysis", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 4: DOCTOR DOSSIERS
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_doctor_dossiers import handle_run_doctor_dossiers
    except ImportError:
        handle_run_doctor_dossiers = None

    if handle_run_doctor_dossiers:
        # Extract doctor names from prescan data if available
        prescan_data = None
        try:
            from .session_archive import load_tool_output
            prescan_data = load_tool_output(session_hash, "prescan-data")
        except Exception:
            pass

        doctors = []
        if prescan_data and isinstance(prescan_data, dict):
            doctors = prescan_data.get("doctors") or prescan_data.get("stage_1_financials", {}).get("doctors") or []

        if not doctors:
            doctors = [company_name]  # Fallback: search by clinic name

        if isinstance(doctors, list) and doctors:
            if isinstance(doctors[0], dict):
                doctor_names = [d.get("name") or d.get("full_name", "") for d in doctors[:5]]
                doctor_names = [n for n in doctor_names if n]
            else:
                doctor_names = [str(d) for d in doctors[:5] if d]

            if not doctor_names:
                doctor_names = [company_name]

            all_dossiers = []
            for dname in doctor_names:
                d_result = await _run_phase(
                    f"Doctor: {dname[:30]}", handle_run_doctor_dossiers,
                    {"doctor_name": dname},
                    session_hash, f"doctor_{dname[:20]}" if len(doctor_names) == 1 else None,
                )
                if d_result:
                    all_dossiers.append(d_result)

            if all_dossiers:
                save_tool_output(session_hash, "doctor_dossiers", {"doctors": all_dossiers})

        all_phases.append(("doctor_dossiers", bool(all_dossiers if 'all_dossiers' in dir() else False)))
    else:
        all_phases.append(("doctor_dossiers", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 5: INSTAGRAM CONTENT
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_instagram_content import handle_run_instagram_content
    except ImportError:
        handle_run_instagram_content = None

    if handle_run_instagram_content:
        handles = []
        if instagram:
            handles = [instagram.strip("@")]
        else:
            # Try to find Instagram from prescan
            try:
                from .session_archive import load_tool_output
                ps = load_tool_output(session_hash, "prescan-data")
                if ps and isinstance(ps, dict):
                    social = ps.get("social_links", {}) or {}
                    ig_from_prescan = social.get("instagram") or ps.get("instagram")
                    if ig_from_prescan:
                        handles = [ig_from_prescan.strip("@").split("/")[-1]]
            except Exception:
                pass

        if handles:
            ig_result = await _run_phase(
                f"Instagram: @{handles[0]}", handle_run_instagram_content,
                {"handle": handles[0]},
                session_hash, "instagram_content",
            )
            all_phases.append(("instagram_content", bool(ig_result and not ig_result.get("error"))))
        else:
            all_phases.append(("instagram_content", "skipped_no_handle"))
    else:
        all_phases.append(("instagram_content", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 6: SMI MENTIONS
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_smi_mentions import handle_run_smi_mentions
    except ImportError:
        handle_run_smi_mentions = None

    if handle_run_smi_mentions:
        await _run_phase(
            "SMI Mentions", handle_run_smi_mentions,
            {"company_name": company_name},
            session_hash, "smi_mentions",
        )
        all_phases.append(("smi_mentions", True))
    else:
        all_phases.append(("smi_mentions", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 7: PAGESPEED
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_pagespeed import handle_run_pagespeed
    except ImportError:
        handle_run_pagespeed = None

    if handle_run_pagespeed:
        await _run_phase(
            "PageSpeed", handle_run_pagespeed,
            {"website": url},
            session_hash, "pagespeed",
        )
        all_phases.append(("pagespeed", True))
    else:
        all_phases.append(("pagespeed", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 8: REVIEW PLATFORMS
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_review_platforms import handle_run_review_platforms
    except ImportError:
        handle_run_review_platforms = None

    if handle_run_review_platforms:
        await _run_phase(
            "Review Platforms", handle_run_review_platforms,
            {"company_name": company_name, "city": city},
            session_hash, "review_platforms",
        )
        all_phases.append(("review_platforms", True))
    else:
        all_phases.append(("review_platforms", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 9: FINANCIALS (FNS)
    # ═════════════════════════════════════════════════════════════════
    try:
        from .find_company_financials import handle_find_company_financials
    except ImportError:
        handle_find_company_financials = None

    if handle_find_company_financials:
        # Get INN from prescan data
        inn = None
        try:
            from .session_archive import load_tool_output
            ps = load_tool_output(session_hash, "prescan-data")
            if ps and isinstance(ps, dict):
                inn = ps.get("inn") or ps.get("stage_1_financials", {}).get("inn")
        except Exception:
            pass

        if inn:
            fin_result = await _run_phase(
                f"Financials (ИНН: {inn})", handle_find_company_financials,
                {"inn": inn},
                session_hash, "financials",
            )
            all_phases.append(("financials", bool(fin_result and fin_result.get("found"))))
        else:
            all_phases.append(("financials", "skipped_no_inn"))
    else:
        all_phases.append(("financials", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 10: SEO AUDIT (deep)
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_seo_audit import handle_run_seo_audit
    except ImportError:
        handle_run_seo_audit = None

    if handle_run_seo_audit:
        await _run_phase(
            "SEO Audit", handle_run_seo_audit,
            {"url": url},
            session_hash, "seo_audit",
        )
        all_phases.append(("seo_audit", True))
    else:
        all_phases.append(("seo_audit", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 11: ADS INTELLIGENCE
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_ads_intelligence import handle_run_ads_intelligence
    except ImportError:
        handle_run_ads_intelligence = None

    if handle_run_ads_intelligence:
        await _run_phase(
            "Ads Intelligence", handle_run_ads_intelligence,
            {"company_name": company_name, "website": url},
            session_hash, "ads_intelligence",
        )
        all_phases.append(("ads_intelligence", True))
    else:
        all_phases.append(("ads_intelligence", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 12: HH.RU ANALYSIS (job market)
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_hh_analysis import handle_run_hh_analysis
    except ImportError:
        handle_run_hh_analysis = None

    if handle_run_hh_analysis:
        await _run_phase(
            "HH.ru Analysis", handle_run_hh_analysis,
            {"company_name": company_name},
            session_hash, "hh_analysis",
        )
        all_phases.append(("hh_analysis", True))
    else:
        all_phases.append(("hh_analysis", False))

    # ═════════════════════════════════════════════════════════════════
    # Phase 13: CONTENT ANALYSIS (if data available)
    # ═════════════════════════════════════════════════════════════════
    try:
        from .run_content_analysis import handle_run_content_analysis
    except ImportError:
        handle_run_content_analysis = None

    if handle_run_content_analysis:
        await _run_phase(
            "Content Analysis", handle_run_content_analysis,
            {"url": url},
            session_hash, "content_analysis",
        )
        all_phases.append(("content_analysis", True))
    else:
        all_phases.append(("content_analysis", False))

    # ═════════════════════════════════════════════════════════════════
    # GENERATE HTML REPORT
    # ═════════════════════════════════════════════════════════════════
    push_tool_progress("full-scout", "📄 Генерация HTML-отчёта…")

    report_result = None
    try:
        from .generate_html_report import handle_generate_html_report
        report_result_str = await handle_generate_html_report(
            session_hash=session_hash,
            title=f"Разведка: {company_name}",
        )
        report_result = json.loads(report_result_str) if isinstance(report_result_str, str) else report_result_str
        all_phases.append(("html_report", bool(report_result and report_result.get("url"))))
    except Exception as e:
        logger.exception("Report generation failed")
        all_phases.append(("html_report", False))

    # ═════════════════════════════════════════════════════════════════
    # FINALIZE
    # ═════════════════════════════════════════════════════════════════
    upsert_metadata(
        session_hash,
        scan_completed=datetime.now(timezone.utc).isoformat(),
        phases_completed=[p for p, ok in all_phases if ok],
        phases_skipped=[p for p, ok in all_phases if not ok or ok == "skipped_no_handle"],
    )

    push_tool_progress("full-scout", "✅ Полный скаут завершён!")

    # Summary
    completed = sum(1 for _, ok in all_phases if ok is True)
    skipped = sum(1 for _, ok in all_phases if not ok or isinstance(ok, str))
    total = len(all_phases)

    return json.dumps({
        "session_hash": session_hash,
        "client": company_name,
        "phases_total": total,
        "phases_completed": completed,
        "phases_skipped": skipped,
        "phase_details": [{"phase": p, "status": "ok" if ok is True else ("skipped" if isinstance(ok, str) else "failed")} for p, ok in all_phases],
        "report_url": report_result.get("url") if report_result else None,
        "report_path": f"/opt/data/sessions-archive/{session_hash}/report.html",
    }, ensure_ascii=False, indent=2)


# ── Registry ─────────────────────────────────────────────────────────
# Register automatically at module load (consistent with all other tools)
registry.register(
    "run_full_scout",
    toolset="aim-operations",
    schema={
        "url": {"type": "string", "description": "Website URL"},
        "company_name": {"type": "string", "description": "Clinic name"},
        "city": {"type": "string", "description": "City for geo-targeting"},
        "instagram": {"type": "string", "description": "Optional Instagram handle"},
        "session_hash": {"type": "string", "description": "Session archive key"},
        "deep": {"type": "boolean", "description": "Deep CI pass"},
    },
    description="Complete scout pipeline: runs ALL tools and saves to session archive. Generates fully populated HTML report. 45-75 minutes.",
    handler=handle_run_full_scout,
)
