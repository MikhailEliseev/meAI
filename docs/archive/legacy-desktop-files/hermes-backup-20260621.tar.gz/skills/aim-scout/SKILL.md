---
name: aim-scout
version: 1.0.0
description: >-
  AIM Scout — 14-фазная глубокая разведка клиники через PipelineEngine.
  Python-controlled execution. LLM = data interpreter, NOT orchestrator.
  v1.0: initial Hermes skill definition matching engine.py v8 pipeline.
triggers:
  - Клиент прислал URL клиники ("https://...")
  - Команда /scout выполнена
  - Запрос "сделай разведку", "проанализируй сайт", "проверь клинику"
  - run_aim_scout tool invoked
  - Админ сказал "запусти скаут для [url]"
---

# AIM Scout — 14-фазная глубокая разведка

Ты запускаешь **PipelineEngine** — Python-стейт-машину, которая выполняет 14 фаз строго последовательно. Ты НЕ оркестрируешь фазы сам. Python контролирует порядок, ретраи, ротацию ключей.

## ⚡ FULL AUTO MODE

**Никаких подтверждений.** Получил URL → запустил PipelineEngine → показал результат.

Ты НИКОГДА не спрашиваешь:
- «Продолжить?» / «Запустить следующую фазу?» — НЕТ
- «Я нашёл данные, показать?» — НЕТ
- «Нужно ли проверить...?» — НЕТ
- Про API-ключи, кредиты, лимиты — НЕТ (инструменты сами делают fallback)

Ты делаешь ТОЛЬКО:
- Получил URL → `PipelineEngine.execute()` → жди завершения → покажи HTML-отчёт
- Сообщаешь только о КРИТИЧЕСКИХ ошибках (сайт не открылся, все API-ключи exhausted)
- Всё остальное — молча, автоматом

## Запуск

```python
from app.pipeline.engine import PipelineEngine

engine = PipelineEngine()
result = await engine.execute(
    session_id="auto-generated",
    client_url="https://iphk.ru",
    client_name="Институт пластической хирургии",
    mode="presale"
)
# result = {
#   "session_hash": "...",
#   "completed_phases": 11,
#   "failed_phases": 0,
#   "data_dir": "/opt/data/sessions-archive/{hash}/",
#   "report_html": "/opt/data/sessions-archive/{hash}/report.html"
# }
```

**Или** вызови tool `run_aim_scout` с теми же параметрами — он делает то же самое.

## 14 фаз (v8)

| # | Фаза | Инструменты | Таймаут | NO_DATA |
|---|------|------------|---------|---------|
| 0 | PERPLEXITY | `perplexity_search` | 120s | ❌ |
| 1 | COMPETITORS | `find_competitors` + `run_ci_analysis` | 600s | ❌ |
| 2 | TECH AUDIT | `run_pagespeed` + `run_tech_seo_audit` | 300s | ❌ |
| 3 | SOCIAL VERIFIER | `run_review_platforms` | 180s | ✅ |
| 4 | CONTENT ANALYSIS | `run_content_analysis` | 120s | ❌ |
| 5 | KEY PERSONS | `find_doctor_handles` + `run_instagram_content` | 240s | ❌ |
| 6 | HIRING SIGNALS | `run_hh_analysis` | 90s | ✅ |
| 7 | SMI MENTIONS | `run_smi_mentions` | 120s | ✅ |
| 8 | FORUM PAINS | `web_search` | 120s | ✅ |
| 9 | FINANCE | `find_company_financials` | 60s | ✅ |
| 10 | CONTENT PLAN | `run_content_gaps` | 120s | ✅ |
| 11 | HTML BUILD | `generate_html_report` | 120s | ❌ |
| 12 | QC CRITIQUE | LLM-проверка | 90s | ❌ |
| 13 | PRESENTATION | `publish_scout_report` | 60s | ❌ |

## PhaseContract

Каждая фаза имеет контракт:

| Параметр | Описание |
|----------|----------|
| `max_retries` | Повторных попыток (0 = без повторов) |
| `retry_on_key_exhaustion` | Ротировать API-ключи при exhausted |
| `allow_no_data` | NO_DATA = легитимный исход, не ошибка |
| `timeout` | Таймаут фазы в секундах |
| `on_permanent_failure` | "skip" — пропустить, "abort" — остановить пайплайн |

**NO_DATA — не ошибка.** Для SOCIAL VERIFIER, HIRING SIGNALS, SMI MENTIONS, FORUM PAINS, FINANCE, CONTENT PLAN пустой результат — нормально.

**Retry с ротацией ключей.** Если инструмент падает с «Insufficient credits», «402», «401» или «exhausted» — Python ротирует API-ключ и повторяет.

## Данные

Все результаты сохраняются в `/opt/data/sessions-archive/{session_hash}/`:

```
data/
  PERPLEXITY.json              # market_research
  COMPETITORS.json              # competitors + ci_analysis
  TECH AUDIT.json               # pagespeed + seo_audit
  SOCIAL VERIFIER.json          # review_platforms
  CONTENT ANALYSIS.json         # content_analysis
  KEY PERSONS.json              # doctor_dossiers + instagram_content
  HIRING SIGNALS.json           # hh_analysis
  SMI MENTIONS.json             # smi_mentions
  FORUM PAINS.json              # forum_pains
  FINANCE.json                  # financials
  CONTENT PLAN.json             # content_gaps
  *_interpretation.json         # LLM-интерпретация каждой фазы
metadata.json                   # {completed_phases, failed_phases, ...}
report.html                     # HTML-отчёт
```

## Завершение

Когда PipelineEngine завершил работу:
1. Проверь `metadata.json` — `completed_phases`, `failed_phases`
2. Проверь `report.html` существует
3. Если published — дай клиенту ссылку на WordPress (из `PRESENTATION.json`)
4. Если saved_locally — скажи где лежит файл

## Iron Rules

1. **Не оркестрируешь сам.** PipelineEngine.execute() — и всё.
2. **Не прерываешься.** Пайплайн идёт 5-10 минут. Жди.
3. **Не спрашиваешь.** FULL AUTO.
4. **Не выдумываешь данные.** Нет данных → честно говоришь.
5. **Только коммерческая медицина.** Никаких ГАУЗ, ГБУЗ, ГУЗ, МУЗ, МБУЗ.
6. **Инфраструктурные ошибки — не для клиента.** Кредиты, ключи, лимиты — наши проблемы.
7. **PipelineEngine — единственный способ запуска.** Не вызывай фазы по отдельности.
