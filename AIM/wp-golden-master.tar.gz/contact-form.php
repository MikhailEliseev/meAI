<!-- Contact Form with PD Consent -->
<form id="aim-contact-form" class="aim-contact-form" method="post">
	<div class="form-group">
		<label for="contact-name">Имя <span class="required">*</span></label>
		<input type="text" id="contact-name" name="name" required placeholder="Ваше имя">
	</div>

	<div class="form-group">
		<label for="contact-email">Email <span class="required">*</span></label>
		<input type="email" id="contact-email" name="email" required placeholder="your@email.com">
	</div>

	<div class="form-group">
		<label for="contact-phone">Телефон</label>
		<input type="tel" id="contact-phone" name="phone" placeholder="+7 (___) ___-__-__">
	</div>

	<div class="form-group">
		<label for="contact-message">Сообщение <span class="required">*</span></label>
		<textarea id="contact-message" name="message" rows="4" required placeholder="Расскажите о вашем проекте..."></textarea>
	</div>

	<div class="form-consent">
		<label class="consent-label">
			<input type="checkbox" id="consent-pd" name="consent_pd" required>
			<span>Согласен с <a href="/privacy-policy/" target="_blank">обработкой персональных данных</a> и <a href="/terms-of-service/" target="_blank">пользовательским соглашением</a></span>
		</label>
	</div>

	<button type="submit" class="btn-submit" id="contact-submit">
		<span class="btn-text">Отправить</span>
		<span class="btn-loading" style="display:none;">Отправка...</span>
	</button>

	<div class="form-message" id="form-message" style="display:none;"></div>
</form>

<style>
.aim-contact-form {
	max-width: 600px;
	margin: 0 auto;
}
.form-group {
	margin-bottom: 20px;
}
.form-group label {
	display: block;
	font-family: 'Jost', sans-serif;
	font-size: .9rem;
	font-weight: 500;
	color: var(--text, #1a1a1a);
	margin-bottom: 8px;
}
.form-group .required {
	color: #dc2626;
}
.form-group input,
.form-group textarea {
	width: 100%;
	padding: 12px 16px;
	font-family: 'Jost', sans-serif;
	font-size: 1rem;
	color: var(--text, #1a1a1a);
	background: var(--surface, #ffffff);
	border: 1px solid var(--border, rgba(0,0,0,.15));
	border-radius: 6px;
	transition: border-color .2s;
}
.form-group input:focus,
.form-group textarea:focus {
	outline: none;
	border-color: var(--accent, #1a1a1a);
}
.form-group textarea {
	resize: vertical;
	min-height: 120px;
}
.form-consent {
	margin: 24px 0;
}
.consent-label {
	display: flex;
	align-items: start;
	gap: 10px;
	cursor: pointer;
	font-family: 'Jost', sans-serif;
	font-size: .9rem;
	color: var(--text-secondary, #4a4a4a);
	line-height: 1.5;
}
.consent-label input[type="checkbox"] {
	margin-top: 3px;
	width: 18px;
	height: 18px;
	cursor: pointer;
	flex-shrink: 0;
}
.consent-label a {
	color: var(--accent, #1a1a1a);
	text-decoration: underline;
	transition: opacity .2s;
}
.consent-label a:hover {
	opacity: .7;
}
.btn-submit {
	width: 100%;
	padding: 14px 24px;
	font-family: 'Jost', sans-serif;
	font-size: 1rem;
	font-weight: 500;
	color: white;
	background: var(--accent, #1a1a1a);
	border: none;
	border-radius: 6px;
	cursor: pointer;
	transition: opacity .2s;
}
.btn-submit:hover:not(:disabled) {
	opacity: .85;
}
.btn-submit:disabled {
	opacity: .5;
	cursor: not-allowed;
}
.form-message {
	margin-top: 16px;
	padding: 12px 16px;
	font-family: 'Jost', sans-serif;
	font-size: .9rem;
	border-radius: 6px;
	text-align: center;
}
.form-message.success {
	color: #15803d;
	background: #dcfce7;
	border: 1px solid #86efac;
}
.form-message.error {
	color: #991b1b;
	background: #fee2e2;
	border: 1px solid #fca5a5;
}

[data-theme="dark"] .form-group label {
	color: var(--text, #f5f0e8);
}
[data-theme="dark"] .form-group input,
[data-theme="dark"] .form-group textarea {
	color: var(--text, #f5f0e8);
	background: var(--surface, #2a2a2a);
	border-color: var(--border, rgba(255,255,255,.15));
}
[data-theme="dark"] .consent-label {
	color: var(--text-secondary, #b8b8b8);
}
[data-theme="dark"] .consent-label a {
	color: var(--accent-light, #c9a96e);
}

@media (max-width: 768px) {
	.form-group input,
	.form-group textarea {
		font-size: .95rem;
	}
}
</style>

<script>
(function() {
	const form = document.getElementById('aim-contact-form');
	const submitBtn = document.getElementById('contact-submit');
	const btnText = submitBtn.querySelector('.btn-text');
	const btnLoading = submitBtn.querySelector('.btn-loading');
	const formMessage = document.getElementById('form-message');
	const consentCheckbox = document.getElementById('consent-pd');

	form.addEventListener('submit', async function(e) {
		e.preventDefault();

		if (!consentCheckbox.checked) {
			showMessage('Необходимо согласие на обработку персональных данных', 'error');
			return;
		}

		submitBtn.disabled = true;
		btnText.style.display = 'none';
		btnLoading.style.display = 'inline';
		formMessage.style.display = 'none';

		const formData = new FormData(form);
		const data = {
			name: formData.get('name'),
			email: formData.get('email'),
			phone: formData.get('phone'),
			message: formData.get('message'),
			consent_pd: consentCheckbox.checked
		};

		try {
			const response = await fetch('/wp-json/aim/v1/contact', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify(data)
			});

			const result = await response.json();

			if (response.ok) {
				showMessage('Спасибо! Ваше сообщение отправлено.', 'success');
				form.reset();
			} else {
				showMessage(result.message || 'Произошла ошибка при отправке', 'error');
			}
		} catch (error) {
			showMessage('Ошибка соединения. Попробуйте позже.', 'error');
		} finally {
			submitBtn.disabled = false;
			btnText.style.display = 'inline';
			btnLoading.style.display = 'none';
		}
	});

	function showMessage(text, type) {
		formMessage.textContent = text;
		formMessage.className = 'form-message ' + type;
		formMessage.style.display = 'block';
	}
})();
</script>
