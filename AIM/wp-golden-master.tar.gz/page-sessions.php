<?php
/**
 * Template Name: Sessions Archive
 * Description: Admin-only page for viewing archived chat sessions
 */

// Security: only admins can access
if (!current_user_can('manage_options')) {
    wp_redirect(home_url());
    exit;
}

get_header();
?>

<div class="sessions-archive-container" style="max-width: 1400px; margin: 0 auto; padding: 2rem;">
    <div class="sessions-header" style="margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: center;">
        <div>
            <h1 style="font-family: 'Playfair Display', serif; font-size: 2.5rem; margin-bottom: 0.5rem;">Архив сессий</h1>
            <p style="color: var(--text-muted); font-size: 0.95rem;">Все разговоры с клиентами через чат на сайте</p>
        </div>
        <button id="archive-all-btn" class="btn-primary" style="padding: 0.75rem 1.5rem; background: var(--accent); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 500; transition: all 0.2s;">
            Архивировать все сессии
        </button>
    </div>

    <div id="sessions-stats" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
        <!-- Stats cards will be inserted here -->
    </div>

    <div id="sessions-list" style="display: grid; gap: 1rem;">
        <div style="text-align: center; padding: 3rem; color: var(--text-muted);">
            Загрузка сессий...
        </div>
    </div>
</div>

<style>
.session-card {
    background: var(--surface);
    border: 1px solid var(--border-subtle);
    border-radius: 12px;
    padding: 1.5rem;
    transition: all 0.2s;
    cursor: pointer;
}

.session-card:hover {
    border-color: var(--accent);
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    transform: translateY(-2px);
}

.session-header {
    display: flex;
    justify-content: space-between;
    align-items: start;
    margin-bottom: 1rem;
}

.session-hash {
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--ink);
}

.session-status {
    padding: 0.25rem 0.75rem;
    border-radius: 16px;
    font-size: 0.8rem;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.status-presale {
    background: rgba(59, 130, 246, 0.1);
    color: rgb(59, 130, 246);
}

.session-meta {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 0.75rem;
    margin-bottom: 1rem;
}

.meta-item {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.meta-label {
    font-size: 0.75rem;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.meta-value {
    font-size: 0.95rem;
    color: var(--ink);
    font-weight: 500;
}

.progress-indicators {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
}

.progress-badge {
    padding: 0.35rem 0.75rem;
    border-radius: 6px;
    font-size: 0.8rem;
    display: flex;
    align-items: center;
    gap: 0.35rem;
}

.progress-badge.done {
    background: rgba(34, 197, 94, 0.1);
    color: rgb(34, 197, 94);
}

.progress-badge.pending {
    background: rgba(156, 163, 175, 0.1);
    color: rgb(156, 163, 175);
}

.stats-card {
    background: var(--surface);
    border: 1px solid var(--border-subtle);
    border-radius: 12px;
    padding: 1.5rem;
    text-align: center;
}

.stats-value {
    font-size: 2rem;
    font-weight: 700;
    color: var(--accent);
    font-family: 'Playfair Display', serif;
}

.stats-label {
    font-size: 0.85rem;
    color: var(--text-muted);
    margin-top: 0.5rem;
}
</style>

<script>
(async function() {
    const sessionsList = document.getElementById('sessions-list');
    const sessionsStats = document.getElementById('sessions-stats');
    const archiveAllBtn = document.getElementById('archive-all-btn');

    // Fetch sessions
    async function loadSessions() {
        try {
            const response = await fetch('/wp-json/aim/v1/sessions');
            const data = await response.json();

            if (!data.sessions || data.sessions.length === 0) {
                sessionsList.innerHTML = '<div style="text-align: center; padding: 3rem; color: var(--text-muted);">Пока нет архивных сессий. Нажмите "Архивировать все сессии" чтобы создать архив.</div>';
                return;
            }

            // Calculate stats
            const stats = {
                total: data.total,
                withContact: data.sessions.filter(s => s.metadata.lead_info.contact_collected).length,
                withPrescan: data.sessions.filter(s => s.metadata.lead_info.prescan_run).length,
                withCI: data.sessions.filter(s => s.metadata.lead_info.ci_analysis_run).length,
            };

            // Render stats
            sessionsStats.innerHTML = `
                <div class="stats-card">
                    <div class="stats-value">${stats.total}</div>
                    <div class="stats-label">Всего сессий</div>
                </div>
                <div class="stats-card">
                    <div class="stats-value">${stats.withContact}</div>
                    <div class="stats-label">Контакты собраны</div>
                </div>
                <div class="stats-card">
                    <div class="stats-value">${stats.withPrescan}</div>
                    <div class="stats-label">Прескан выполнен</div>
                </div>
                <div class="stats-card">
                    <div class="stats-value">${stats.withCI}</div>
                    <div class="stats-label">CI-анализ выполнен</div>
                </div>
            `;

            // Render sessions
            sessionsList.innerHTML = data.sessions.map(session => {
                const meta = session.metadata;
                const lead = meta.lead_info;
                const createdDate = new Date(meta.created_at).toLocaleString('ru-RU', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                });

                return `
                    <div class="session-card" onclick="window.location.href='?session=${session.hash}'">
                        <div class="session-header">
                            <div class="session-hash">${session.hash}</div>
                            <div class="session-status status-${lead.status}">${lead.status}</div>
                        </div>

                        <div class="session-meta">
                            <div class="meta-item">
                                <div class="meta-label">Дата</div>
                                <div class="meta-value">${createdDate}</div>
                            </div>
                            <div class="meta-item">
                                <div class="meta-label">Сообщений</div>
                                <div class="meta-value">${meta.message_count}</div>
                            </div>
                            <div class="meta-item">
                                <div class="meta-label">URL клиента</div>
                                <div class="meta-value">${lead.client_url ? lead.client_url.replace(/^https?:\/\//, '') : '—'}</div>
                            </div>
                        </div>

                        <div class="progress-indicators">
                            <div class="progress-badge ${lead.prescan_run ? 'done' : 'pending'}">
                                ${lead.prescan_run ? '✓' : '○'} Прескан
                            </div>
                            <div class="progress-badge ${lead.competitors_found ? 'done' : 'pending'}">
                                ${lead.competitors_found ? '✓' : '○'} Конкуренты
                            </div>
                            <div class="progress-badge ${lead.ci_analysis_run ? 'done' : 'pending'}">
                                ${lead.ci_analysis_run ? '✓' : '○'} CI-анализ
                            </div>
                            <div class="progress-badge ${lead.contact_collected ? 'done' : 'pending'}">
                                ${lead.contact_collected ? '✓' : '○'} Контакт
                            </div>
                        </div>
                    </div>
                `;
            }).join('');

        } catch (error) {
            console.error('Failed to load sessions:', error);
            sessionsList.innerHTML = '<div style="text-align: center; padding: 3rem; color: var(--text-destructive);">Ошибка загрузки сессий</div>';
        }
    }

    // Archive all sessions
    archiveAllBtn.addEventListener('click', async function() {
        if (!confirm('Архивировать все сессии (минимум 3 сообщения)? Это может занять несколько секунд.')) {
            return;
        }

        archiveAllBtn.disabled = true;
        archiveAllBtn.textContent = 'Архивирую...';

        try {
            const response = await fetch('/wp-json/aim/v1/sessions/archive-all', {
                method: 'POST'
            });
            const data = await response.json();

            if (data.success) {
                alert(`Успешно архивировано: ${data.archived_count} сессий`);
                loadSessions(); // Reload
            } else {
                alert('Ошибка архивирования');
            }
        } catch (error) {
            console.error('Archive failed:', error);
            alert('Ошибка архивирования');
        } finally {
            archiveAllBtn.disabled = false;
            archiveAllBtn.textContent = 'Архивировать все сессии';
        }
    });

    // Load sessions on page load
    loadSessions();
})();
</script>

<?php get_footer(); ?>
