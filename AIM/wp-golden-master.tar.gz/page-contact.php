<?php
/**
 * Contact page template — AIM Design System
 */
get_header();

$form_sent = false;
$form_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aim_contact_nonce'])) {
    if (wp_verify_nonce($_POST['aim_contact_nonce'], 'aim_contact_submit')) {
        $name = sanitize_text_field($_POST['contact_name'] ?? '');
        $email = sanitize_email($_POST['contact_email'] ?? '');
        $messenger = sanitize_text_field($_POST['contact_messenger'] ?? '');
        $question = sanitize_textarea_field($_POST['contact_question'] ?? '');

        if (empty($name) || empty($email) || empty($question)) {
            $form_error = 'Пожалуйста, заполните обязательные поля.';
        } elseif (!is_email($email)) {
            $form_error = 'Пожалуйста, укажите корректный email.';
        } else {
            $to = get_option('admin_email');
            $subject = "AIM: вопрос от $name";
            $body = "Имя: $name\nEmail: $email\nMessenger: $messenger\n\nВопрос:\n$question";
            $headers = ['Content-Type: text/plain; charset=UTF-8', "From: $name <$email>"];
            wp_mail($to, $subject, $body, $headers);
            $form_sent = true;
        }
    }
}
?>
<style>
.contact-page{max-width:1000px;margin:0 auto;padding:60px 24px 80px}
.contact-header{text-align:center;margin-bottom:48px}
.contact-title{font-family:'Playfair Display',serif;font-size:clamp(2rem,4vw,2.75rem);font-weight:400;letter-spacing:-.02em;color:var(--text,#1a1a1a);margin:0 0 12px;line-height:1.2}
.contact-subtitle{font-family:'Jost',sans-serif;font-size:1.05rem;color:var(--text-secondary,#6b6b6b);line-height:1.6;max-width:480px;margin:0 auto}
.contact-layout{display:grid;grid-template-columns:1fr 1fr;gap:1px;max-width:900px;margin:0 auto;background:var(--border,rgba(0,0,0,.08))}
.contact-info{background:var(--surface,#fff);padding:40px 36px;display:flex;flex-direction:column;gap:24px}
.contact-info-title{font-family:'Playfair Display',serif;font-size:1.35rem;font-weight:500;color:var(--text,#1a1a1a);margin:0}
.contact-info-item{display:flex;align-items:flex-start;gap:12px;font-family:'Jost',sans-serif;font-size:.95rem;line-height:1.6;color:var(--text-secondary,#6b6b6b)}
.contact-info-item-icon{font-family:'Playfair Display',serif;font-size:1.1rem;color:var(--accent,#1a1a1a);flex-shrink:0;width:24px;text-align:center}
.contact-info-item a{color:var(--accent,#1a1a1a);text-decoration:none;transition:opacity .2s}
.contact-info-item a:hover{opacity:.7}
.contact-form-panel{background:var(--surface,#fff);padding:40px 36px}
.contact-form{display:flex;flex-direction:column;gap:20px}
.contact-form-group{display:flex;flex-direction:column;gap:6px}
.contact-form-label{font-family:'Jost',sans-serif;font-size:.8rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--text-secondary,#6b6b6b)}
.contact-form-label .required{color:var(--accent,#1a1a1a)}
.contact-form-input{font-family:'Jost',sans-serif;font-size:.95rem;padding:12px 14px;border:1px solid var(--border,rgba(0,0,0,.15));border-radius:6px;background:var(--bg,#fff);color:var(--text,#1a1a1a);transition:border-color .2s,box-shadow .2s;outline:none;width:100%;box-sizing:border-box}
.contact-form-input:focus{border-color:var(--accent,#1a1a1a);box-shadow:0 0 0 3px rgba(201,169,110,.15)}
.contact-form-input::placeholder{color:var(--text-secondary,#999)}
textarea.contact-form-input{resize:vertical;min-height:120px}
.contact-form-submit{font-family:'Jost',sans-serif;font-size:.9rem;font-weight:600;letter-spacing:.04em;padding:14px 28px;background:var(--accent,#1a1a1a);color:var(--bg,#fff);border:none;border-radius:6px;cursor:pointer;transition:opacity .2s,transform .2s;align-self:flex-start}
.contact-form-submit:hover{opacity:.85;transform:translateY(-1px)}
.contact-form-error{font-family:'Jost',sans-serif;font-size:.85rem;color:#c44;padding:10px 14px;background:rgba(204,68,68,.08);border-radius:6px}
.contact-form-success{text-align:center;padding:40px 20px}
.contact-form-success-icon{font-family:'Playfair Display',serif;font-size:2.5rem;color:var(--accent,#1a1a1a);margin-bottom:12px}
.contact-form-success-title{font-family:'Playfair Display',serif;font-size:1.35rem;font-weight:500;color:var(--text,#1a1a1a);margin:0 0 8px}
.contact-form-success-text{font-family:'Jost',sans-serif;font-size:.95rem;color:var(--text-secondary,#6b6b6b);line-height:1.6}
[data-theme="dark"] .contact-form-input{background:var(--surface,#1a1a1a);border-color:var(--border,rgba(201,169,110,.18))}
[data-theme="dark"] .contact-form-input:focus{box-shadow:0 0 0 3px rgba(201,169,110,.2)}
[data-theme="dark"] .contact-form-submit{color:#0d0d0d}
@media(max-width:768px){
.contact-page{padding:40px 20px 60px}
.contact-layout{grid-template-columns:1fr}
.contact-info,.contact-form-panel{padding:28px 24px}
}
</style>
<div class="contact-page">
  <header class="contact-header">
    <h1 class="contact-title">Свяжитесь с нами</h1>
    <p class="contact-subtitle">Задайте вопрос или расскажите о вашей клинике — мы ответим в течение 24 часов.</p>
  </header>
  <div class="contact-layout">
    <div class="contact-info">
      <h2 class="contact-info-title">Контакты</h2>
      <div class="contact-info-item">
        <span class="contact-info-item-icon">✉</span>
        <span>hello@iamaim.ru</span>
      </div>
      <div class="contact-info-item">
        <span class="contact-info-item-icon">@</span>
        <a href="https://t.me/mikhaileliseev" target="_blank" rel="noopener">@mikhaileliseev</a>
      </div>
      <div class="contact-info-item">
        <span class="contact-info-item-icon">☎</span>
        <span>+7 968 475-77-66</span>
      </div>
    </div>
    <div class="contact-form-panel">
      <?php if ($form_sent): ?>
      <div class="contact-form-success">
        <div class="contact-form-success-icon">✓</div>
        <h3 class="contact-form-success-title">Спасибо!</h3>
        <p class="contact-form-success-text">Ваше сообщение отправлено. Мы ответим в ближайшее время.</p>
      </div>
      <?php else: ?>
      <form class="contact-form" method="POST" action="">
        <?php wp_nonce_field('aim_contact_submit', 'aim_contact_nonce'); ?>
        <?php if ($form_error): ?>
        <div class="contact-form-error"><?php echo esc_html($form_error); ?></div>
        <?php endif; ?>
        <div class="contact-form-group">
          <label class="contact-form-label" for="contact_name">Имя <span class="required">*</span></label>
          <input class="contact-form-input" type="text" id="contact_name" name="contact_name" placeholder="Анна Петрова" required value="<?php echo esc_attr($_POST['contact_name'] ?? ''); ?>">
        </div>
        <div class="contact-form-group">
          <label class="contact-form-label" for="contact_email">Email <span class="required">*</span></label>
          <input class="contact-form-input" type="email" id="contact_email" name="contact_email" placeholder="anna@clinic.ru" required value="<?php echo esc_attr($_POST['contact_email'] ?? ''); ?>">
        </div>
        <div class="contact-form-group">
          <label class="contact-form-label" for="contact_messenger">Telegram или WhatsApp</label>
          <input class="contact-form-input" type="text" id="contact_messenger" name="contact_messenger" placeholder="@username или +7 9XX XXX-XX-XX" value="<?php echo esc_attr($_POST['contact_messenger'] ?? ''); ?>">
        </div>
        <div class="contact-form-group">
          <label class="contact-form-label" for="contact_question">Ваш вопрос <span class="required">*</span></label>
          <textarea class="contact-form-input" id="contact_question" name="contact_question" placeholder="Расскажите о вашей клинике и задаче..." required><?php echo esc_textarea($_POST['contact_question'] ?? ''); ?></textarea>
        </div>
        <button class="contact-form-submit" type="submit">Отправить →</button>
      </form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php get_footer(); ?>
