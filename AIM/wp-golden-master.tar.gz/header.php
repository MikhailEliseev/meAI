<!DOCTYPE html>
<html lang="ru-RU" data-theme="light">
<head>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-W6J6MC23');</script>
    <!-- End Google Tag Manager -->
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-site-verification" content="PakjgDerkjEVmZmpT68cBQDTg1-QPH2S9cXMnPpXCY4">
    <meta name="yandex-verification" content="49ad523f61bbd97a">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Jost:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <script>
    (function(){
        var t = localStorage.getItem('aim-theme');
        // Default to light if no preference
        if (t === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        }
    })();
    </script>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "AIM",
      "url": "https://iamaim.ru",
      "description": "AI-first маркетинг в медицине",
      "address": { "@type": "PostalAddress", "addressCountry": "RU", "addressLocality": "Москва" },
      "contactPoint": { "@type": "ContactPoint", "telephone": "+79684757766", "contactType": "customer service" }
    }
    </script>
</head>
<body <?php body_class('bg-canvas text-ink font-sans antialiased'); ?>>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W6J6MC23"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php wp_body_open(); ?>
<header class="fixed top-0 left-0 right-0 z-50 px-6 py-3 bg-canvas/80 backdrop-blur">
    <div class="max-w-7xl mx-auto flex items-center justify-between relative">
        <a href="/" class="logo">AIM</a>
        <span class="hidden md:block" style="position:absolute;left:50%;transform:translateX(-50%);font-size:0.75rem;color:var(--text-dim);font-family:'Jost',sans-serif;letter-spacing:.1em;text-transform:uppercase;pointer-events:none;white-space:nowrap;">AI-first маркетинг в медицине</span>

        <!-- Desktop nav -->
        <nav class="hidden md:flex items-center gap-6 text-base text-text-muted">
            <a href="/prices/" class="hover:text-ink transition-colors no-underline" onclick="window.dataLayer=window.dataLayer||[];dataLayer.push({event:'prices_nav'});if(typeof ym!=='undefined')ym(109826942,'reachGoal','prices_nav');">Цены</a>
            <a href="/research/" class="hover:text-ink transition-colors no-underline">Исследования</a>
            <a href="/blog/" class="hover:text-ink transition-colors no-underline">Блог</a>
            <a href="/philosophy/" class="hover:text-ink transition-colors no-underline">Смысл</a>
            <a href="/contact/" class="hover:text-ink transition-colors no-underline">Контакты</a>
            <a class="hover:text-ink transition-colors no-underline theme-toggle" id="theme-toggle-btn" href="#" onclick="
                var h=document.documentElement;
                var n=h.getAttribute('data-theme')==='dark'?'light':'dark';
                h.setAttribute('data-theme',n);
                localStorage.setItem('aim-theme',n);
                localStorage.setItem('aim-tip-dismissed', '1');
                var t=document.getElementById('theme-tip');
                if(t)t.remove();
                return false;
            " aria-label="Переключить тему" role="button">
                <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
                <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
                <span class="theme-toggle-tip" id="theme-tip">Перейти в тайную комнату</span>
            </a>
        </nav>

        <!-- Hamburger + theme toggle (mobile) -->
        <div class="flex items-center gap-3 md:hidden z-10">
            <a class="theme-toggle" href="#" onclick="
                var h=document.documentElement;
                var n=h.getAttribute('data-theme')==='dark'?'light':'dark';
                h.setAttribute('data-theme',n);
                localStorage.setItem('aim-theme',n);
                localStorage.setItem('aim-tip-dismissed', '1');
                var t=document.getElementById('theme-tip');
                if(t)t.remove();
                return false;
            " aria-label="Переключить тему" role="button">
                <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
                <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
            </a>
            <button class="hamburger" id="hamburger-btn" aria-label="Меню" aria-expanded="false" onclick="document.getElementById('hamburger-btn').classList.toggle('open');document.getElementById('mobile-menu').classList.toggle('open');var ex=document.getElementById('hamburger-btn').getAttribute('aria-expanded')==='true';document.getElementById('hamburger-btn').setAttribute('aria-expanded',!ex);document.body.classList.toggle('menu-open');">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </div>

    <!-- Mobile menu panel -->
    <nav class="mobile-menu" id="mobile-menu">
        <div class="max-w-7xl mx-auto flex flex-col gap-4 pt-2 pb-6">
            <a href="/prices/" class="mobile-nav-link" onclick="window.dataLayer=window.dataLayer||[];dataLayer.push({event:'prices_nav'});if(typeof ym!=='undefined')ym(109826942,'reachGoal','prices_nav');document.getElementById('hamburger-btn').click();">Цены</a>
            <a href="/research/" class="mobile-nav-link" onclick="document.getElementById('hamburger-btn').click();">Исследования</a>
            <a href="/blog/" class="mobile-nav-link" onclick="document.getElementById('hamburger-btn').click();">Блог</a>
            <a href="/philosophy/" class="mobile-nav-link" onclick="document.getElementById('hamburger-btn').click();">Смысл</a>
            <a href="/contact/" class="mobile-nav-link" onclick="document.getElementById('hamburger-btn').click();">Контакты</a>
        </div>
    </nav>

    <script>
    (function(){
        var tip = document.getElementById('theme-tip');
        if (!tip) return;

        if (localStorage.getItem('aim-tip-dismissed')) {
            tip.remove();
            return;
        }

        var currentTheme = document.documentElement.getAttribute('data-theme');
        if (currentTheme === 'dark') {
            tip.remove();
            return;
        }

        if (!localStorage.getItem('aim-tip-shown')) {
            localStorage.setItem('aim-tip-shown', '1');
            setTimeout(function(){
                if (tip) tip.classList.add('show');
            }, 800);
            setTimeout(function(){
                if (tip) tip.classList.remove('show');
            }, 5000);
        }
    })();
    </script>
</header>
<main class="pt-14">
