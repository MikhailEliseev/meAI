<?php
/**
 * Blog listing template — AIM Design System
 * Playfair Display headings + Jost body + glass cards + dual-theme
 */
get_header();
?>
<style>
.blog-hero{text-align:center;padding:80px 24px 64px;max-width:800px;margin:0 auto}
.blog-hero-title{font-family:'Playfair Display',serif;font-size:clamp(2.5rem,5vw,4rem);font-weight:400;letter-spacing:-.02em;color:var(--text,#1a1a1a);margin:0 0 16px;line-height:1.15}
.blog-hero-subtitle{font-family:'Jost',sans-serif;font-size:1.1rem;color:var(--text-secondary,#6b6b6b);font-weight:400;line-height:1.6;max-width:560px;margin:0 auto}
.blog-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:1px;max-width:1200px;margin:0 auto 80px;padding:0 24px;background:var(--border,rgba(0,0,0,.08))}
.blog-card{background:var(--surface,#fff);padding:36px 32px;display:flex;flex-direction:column;gap:14px;transition:all .3s cubic-bezier(.16,1,.3,1);position:relative;overflow:hidden}
.blog-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--accent,#1a1a1a);transform:scaleX(0);transform-origin:left;transition:transform .35s cubic-bezier(.16,1,.3,1)}
.blog-card:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(0,0,0,.06)}
.blog-card:hover::before{transform:scaleX(1)}
.blog-card-categories{display:flex;flex-wrap:wrap;gap:6px}
.blog-card-category{display:inline-flex;align-items:center;gap:5px;font-family:'Jost',sans-serif;font-size:.7rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--accent,#1a1a1a);padding:3px 8px;border-radius:4px;background:var(--surface-2,rgba(0,0,0,.05))}
.blog-card-category::before{content:'';width:4px;height:4px;border-radius:50%;background:var(--accent,#1a1a1a);flex-shrink:0}
.blog-card-meta{font-family:'Jost',sans-serif;font-size:.75rem;font-weight:500;letter-spacing:.08em;text-transform:uppercase;color:var(--text-secondary,#6b6b6b)}
.blog-card-title{font-family:'Playfair Display',serif;font-size:1.5rem;font-weight:500;line-height:1.3;color:var(--text,#1a1a1a);margin:0;letter-spacing:-.01em}
.blog-card-title a{color:inherit;text-decoration:none;transition:color .2s}
.blog-card-title a:hover{color:var(--accent,#1a1a1a)}
.blog-card-excerpt{font-family:'Jost',sans-serif;font-size:.95rem;line-height:1.7;color:var(--text-secondary,#6b6b6b);margin:0;flex:1}
.blog-card-read-more{display:inline-flex;align-items:center;gap:8px;font-family:'Jost',sans-serif;font-size:.85rem;font-weight:500;color:var(--text,#1a1a1a);text-decoration:none;transition:gap .25s cubic-bezier(.16,1,.3,1);align-self:flex-start}
.blog-card-read-more:hover{gap:14px}
.blog-card-read-more-arrow{font-family:'Playfair Display',serif;font-size:1.1rem;transition:transform .25s cubic-bezier(.16,1,.3,1)}
.blog-card-read-more:hover .blog-card-read-more-arrow{transform:translateX(3px)}
.blog-empty{text-align:center;padding:80px 24px;font-family:'Jost',sans-serif;color:var(--text-secondary,#6b6b6b)}
[data-theme="dark"] .blog-card{background:var(--surface,#1a1a1a);backdrop-filter:blur(12px) saturate(1.4);border:1px solid rgba(201,169,110,.08)}
[data-theme="dark"] .blog-card::before{background:var(--accent,#c9a96e)}
[data-theme="dark"] .blog-card:hover{box-shadow:0 8px 32px rgba(0,0,0,.3);border-color:rgba(201,169,110,.2)}
[data-theme="dark"] .blog-grid{background:rgba(201,169,110,.08)}
@media(max-width:768px){.blog-hero{padding:48px 20px 40px}.blog-grid{grid-template-columns:1fr;padding:0 16px}.blog-card{padding:28px 24px}}
</style>
<section class="blog-hero">
  <h1 class="blog-hero-title">Блог AIM</h1>
  <p class="blog-hero-subtitle">AI-first маркетинг в медицине: стратегии, аналитика, кейсы и инструменты для привлечения пациентов в частные клиники.</p>
</section>
<?php if (have_posts()): ?>
<div class="blog-grid">
  <?php while (have_posts()): the_post(); ?>
  <article class="blog-card">
    <?php $cats = get_the_category(); if (!empty($cats)): ?>
    <div class="blog-card-categories">
      <?php foreach (array_slice($cats, 0, 3) as $cat): ?>
      <span class="blog-card-category"><?php echo esc_html($cat->name); ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <div class="blog-card-meta">
      <span><?php echo get_the_date('j F Y'); ?></span>
    </div>
    <h2 class="blog-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
    <p class="blog-card-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt() ?: get_the_content(), 28, '…')); ?></p>
    <a href="<?php the_permalink(); ?>" class="blog-card-read-more">Читать <span class="blog-card-read-more-arrow">→</span></a>
  </article>
  <?php endwhile; ?>
</div>
<nav style="text-align:center;padding:0 24px 60px;font-family:'Jost',sans-serif"><?php the_posts_pagination(array('mid_size' => 2, 'prev_text' => '←', 'next_text' => '→')); ?></nav>
<?php else: ?>
<div class="blog-empty"><p>Статей пока нет. Возвращайтесь скоро!</p></div>
<?php endif; ?>
<?php get_footer(); ?>
