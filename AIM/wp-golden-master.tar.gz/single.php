<?php
/**
 * Single post template — AIM Design System
 */
get_header();
?>
<style>
.blog-single{max-width:1000px;margin:0 auto;padding:60px 24px 80px}
.blog-single-header{text-align:center;margin-bottom:48px}
.blog-single-categories{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-bottom:20px}
.blog-single-category{display:inline-flex;align-items:center;gap:6px;font-family:'Jost',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--accent,#1a1a1a);padding:4px 10px;border-radius:4px;background:var(--surface-2,rgba(0,0,0,.05))}
.blog-single-category::before{content:'';width:5px;height:5px;border-radius:50%;background:var(--accent,#1a1a1a)}
.blog-single-title{font-family:'Playfair Display',serif;font-size:clamp(2rem,4vw,3rem);font-weight:400;letter-spacing:-.02em;color:var(--text,#1a1a1a);margin:0 0 16px;line-height:1.2}
.blog-single-meta{font-family:'Jost',sans-serif;font-size:.85rem;color:var(--text-secondary,#6b6b6b)}
.blog-single-content{font-family:'Jost',sans-serif;font-size:1.05rem;line-height:1.8;color:var(--text,#1a1a1a)}
.blog-single-content h2{font-family:'Playfair Display',serif;font-size:1.75rem;font-weight:500;letter-spacing:-.01em;margin:48px 0 16px;color:var(--text,#1a1a1a)}
.blog-single-content h3{font-family:'Playfair Display',serif;font-size:1.35rem;font-weight:500;margin:36px 0 12px;color:var(--text,#1a1a1a)}
.blog-single-content p{margin:0 0 1.25em}
.blog-single-content ul,.blog-single-content ol{margin:0 0 1.25em;padding-left:1.5em}
.blog-single-content li{margin-bottom:.5em}
.blog-single-content blockquote{font-family:'Playfair Display',serif;font-style:italic;font-size:1.15rem;line-height:1.6;color:var(--text,#1a1a1a);border-left:3px solid var(--accent,#1a1a1a);padding:12px 0 12px 24px;margin:32px 0}
.blog-single-content strong{font-weight:600}
.blog-single-back{display:inline-flex;align-items:center;gap:8px;font-family:'Jost',sans-serif;font-size:.9rem;font-weight:500;color:var(--text-secondary,#6b6b6b);text-decoration:none;margin-bottom:32px;transition:color .2s}
.blog-single-back:hover{color:var(--text,#1a1a1a)}
@media(max-width:768px){.blog-single{padding:40px 20px 60px}}
</style>
<?php while (have_posts()): the_post(); ?>
<article class="blog-single">
  <a href="/blog/" class="blog-single-back"><span style="font-family:'Playfair Display',serif;font-size:1.2rem">←</span> Все статьи</a>
  <header class="blog-single-header">
    <?php $cats = get_the_category(); if (!empty($cats)): ?>
    <div class="blog-single-categories">
      <?php foreach (array_slice($cats, 0, 3) as $cat): ?>
      <span class="blog-single-category"><?php echo esc_html($cat->name); ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <h1 class="blog-single-title"><?php the_title(); ?></h1>
    <div class="blog-single-meta"><?php echo get_the_date('j F Y'); ?></div>
  </header>
  <div class="blog-single-content"><?php the_content(); ?></div>
</article>
<?php endwhile; ?>
<?php get_footer(); ?>
