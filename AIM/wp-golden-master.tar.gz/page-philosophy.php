<?php
/**
 * Template Name: Philosophy Page (Gumirov)
 * Description: Смысл AIM — зачем и как мы работаем
 */
get_header();
?>

<style>
.philosophy-page {
  max-width: 1000px;
  margin: 0 auto;
  padding: 4rem 1rem;
  line-height: 1.7;
}

.philosophy-hero {
  text-align: center;
  margin-bottom: 4rem;
  padding-bottom: 3rem;
  border-bottom: 1px solid var(--border);
}

.philosophy-hero h1 {
  font-family: 'Playfair Display', serif;
  font-size: 3rem;
  line-height: 1.2;
  margin-bottom: 1rem;
  color: var(--text);
}

.philosophy-section {
  margin-bottom: 4rem;
  padding-bottom: 3rem;
  border-bottom: 1px solid var(--border);
}

.philosophy-section:last-of-type {
  border-bottom: none;
}

.philosophy-section h2 {
  font-family: 'Playfair Display', serif;
  font-size: 2.25rem;
  line-height: 1.3;
  margin-bottom: 2rem;
  color: var(--text);
}

.philosophy-section h3 {
  font-size: 1.5rem;
  margin: 2rem 0 1rem;
  color: var(--text);
  font-family: 'Playfair Display', serif;
  font-weight: 500;
}

.philosophy-section p {
  font-size: 1.125rem;
  margin-bottom: 1.5rem;
  color: var(--text);
}

.philosophy-section ul {
  list-style: none;
  padding: 0;
  margin: 1.5rem 0;
}

.philosophy-section ul li {
  font-size: 1.125rem;
  margin-bottom: 0.75rem;
  padding-left: 1.5rem;
  position: relative;
  color: var(--text);
}

.philosophy-section ul li:before {
  content: "—";
  position: absolute;
  left: 0;
  color: var(--accent);
}

.philosophy-section strong {
  color: var(--accent);
  font-weight: 600;
}

.philosophy-section ol {
  padding-left: 1.5rem;
  margin: 1.5rem 0;
}

.philosophy-section ol li {
  font-size: 1.125rem;
  margin-bottom: 0.75rem;
  color: var(--text);
}

/* Glass блоки из дизайн-системы */
.card-glass {
  background: var(--glass-bg);
  backdrop-filter: blur(20px) saturate(1.4);
  border: 1px solid var(--glass-border);
  border-radius: 12px;
  padding: 2rem;
  margin: 2rem 0;
}

.card-glass h3 {
  font-family: 'Playfair Display', serif;
  font-size: 1.5rem;
  font-weight: 500;
  margin-bottom: 1rem;
  color: var(--text);
}

.card-glass p {
  margin-bottom: 1rem;
}

.card-glass p:last-child {
  margin-bottom: 0;
}

/* Blockquote из дизайн-системы */
blockquote {
  font-family: 'Playfair Display', serif;
  font-size: 1.5rem;
  font-weight: 400;
  font-style: italic;
  color: var(--text);
  line-height: 1.5;
  margin: 2rem 0;
  padding-left: 2rem;
  border-left: 3px solid var(--accent);
}

blockquote strong {
  color: var(--accent);
  font-weight: 600;
  font-style: normal;
}

/* Hook box */
.hook-box {
  background: var(--glass-bg);
  backdrop-filter: blur(20px) saturate(1.4);
  border: 2px solid var(--accent);
  border-radius: 12px;
  padding: 2rem;
  margin: 2rem 0;
  text-align: center;
}

.hook-box h2 {
  font-size: 1.75rem;
  margin: 0;
  color: var(--accent);
}

/* Comparison table */
.comparison-table {
  width: 100%;
  margin: 2rem 0;
  border-collapse: collapse;
  font-size: 1rem;
}

.comparison-table th,
.comparison-table td {
  padding: 1rem;
  text-align: left;
  border-bottom: 1px solid var(--border);
}

.comparison-table th {
  font-weight: 600;
  color: var(--accent);
  font-family: 'Playfair Display', serif;
}

.comparison-table tr:last-child td {
  border-bottom: none;
}

.comparison-table td:nth-child(3) {
  color: var(--accent);
  font-weight: 600;
}

/* Two columns */
.two-columns {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  margin: 2rem 0;
}

.two-columns .column {
  background: var(--glass-bg);
  backdrop-filter: blur(20px) saturate(1.4);
  border: 1px solid var(--glass-border);
  border-radius: 12px;
  padding: 1.5rem;
}

.two-columns .column h4 {
  margin-top: 0;
  margin-bottom: 1rem;
  font-family: 'Playfair Display', serif;
  font-size: 1.25rem;
  color: var(--text);
}

/* FAQ items */
.faq-item {
  margin-bottom: 2rem;
  padding-bottom: 2rem;
  border-bottom: 1px solid var(--border);
}

.faq-item:last-child {
  border-bottom: none;
}

.faq-item h3 {
  font-size: 1.5rem;
  margin-bottom: 1rem;
  color: var(--text);
}

/* CTA box */
.cta-box {
  text-align: center;
  background: var(--glass-bg);
  backdrop-filter: blur(20px) saturate(1.4);
  border: 2px solid var(--accent);
  border-radius: 12px;
  padding: 3rem 2rem;
  margin: 3rem 0;
}

.cta-box h3 {
  margin-bottom: 1rem;
  font-family: 'Playfair Display', serif;
}

.cta-box p {
  margin-bottom: 2rem;
}

/* Final punch */
.final-punch {
  text-align: center;
  font-family: 'Playfair Display', serif;
  font-size: 1.75rem;
  font-weight: 500;
  color: var(--accent);
  margin: 3rem 0;
  padding: 2rem;
  border-top: 2px solid var(--accent);
  border-bottom: 2px solid var(--accent);
  line-height: 1.4;
}

/* Accent text */
.accent-text {
  color: var(--accent);
  font-weight: 600;
}

/* Section divider */
.section-divider {
  border: none;
  border-top: 1px solid var(--border);
  margin: 3rem 0;
}

@media (max-width: 768px) {
  .philosophy-hero h1 {
    font-size: 2rem;
  }

  .philosophy-section h2 {
    font-size: 1.75rem;
  }

  .two-columns {
    grid-template-columns: 1fr;
  }

  .comparison-table {
    font-size: 0.875rem;
  }

  .comparison-table th,
  .comparison-table td {
    padding: 0.5rem;
  }

  blockquote {
    font-size: 1.25rem;
    padding-left: 1rem;
  }
}
</style>

<div class="philosophy-page">

  <!-- Hero -->
  <div class="philosophy-hero">
    <h1>Почему AI-маркетинг — это не будущее, а настоящее</h1>
  </div>

  <!-- Hook -->
  <div class="hook-box">
    <h2>AI не заменит маркетолога. Но маркетолог с AI обгонит маркетолога без AI</h2>
  </div>

  <div class="philosophy-section">
    <p>Ваше агентство присылает отчёты на 40 страниц. Красивые графики. Таблицы. Выводы. Вы киваете на созвонах, подписываете акты.</p>
    <p><strong>А пациентов не становится больше.</strong></p>

    <blockquote>
      Знаете, в чём дело? <strong>Они анализируют конкурентов вручную. Тратят на это дни. А решения нужно принимать сегодня.</strong>
    </blockquote>

    <p>Не потому что плохие специалисты. Потому что человек устаёт. Пропускает детали. Не видит паттерны, которые заметил бы алгоритм. А рынок не ждёт.</p>
  </div>

  <!-- Проблема -->
  <div class="philosophy-section">
    <h2>Проблема не в людях. Проблема в скорости</h2>
    <p>Пока ваше агентство неделю собирает данные, конкуренты уже тестируют новые связки. Пока они делают аудит, рынок меняется. Пока они думают над стратегией, вы теряете заявки.</p>

    <div class="card-glass">
      <p><strong>Вот где ошибка:</strong> вы платите за процесс («сделали анализ»), а не за результат («пациентов стало больше»).</p>
      <p>Сейчас покажу, как это работает по-другому.</p>
    </div>
  </div>

  <!-- Правило 1 -->
  <div class="philosophy-section">
    <h2>Правило 1: Данные решают всё</h2>
    <p>Никаких «обычно работает» и «мне кажется». <span class="accent-text">Только цифры.</span></p>

    <div class="two-columns">
      <div class="column">
        <h4>Стандартное агентство:</h4>
        <ul>
          <li>Маркетолог: «Там ваша ЦА, давайте Instagram»</li>
          <li>Настраивают, запускают, тратят бюджет</li>
          <li>Через месяц смотрят статистику</li>
        </ul>
      </div>

      <div class="column">
        <h4>AI-подход:</h4>
        <ul>
          <li>Яндекс.Метрика показывает: 70% заявок из поиска</li>
          <li>Конкуренты тратят 80% бюджета на Яндекс.Директ</li>
          <li>Решение: 90% бюджета в поиск, 10% в соцсети</li>
        </ul>
      </div>
    </div>

    <h3>На что смотрим:</h3>
    <div class="card-glass">
      <ul>
        <li>Технический аудит сайта — скорость, мобильная версия, структура</li>
        <li>Позиции по ключевым запросам — не «вы на 5 месте», а «вы теряете заявки, которые получает конкурент»</li>
        <li>Поведение пользователей — где отваливаются, что читают, куда кликают</li>
        <li>Конкуренты — кто они, что делают, какие связки используют</li>
      </ul>
    </div>
  </div>

  <!-- Правило 2 -->
  <div class="philosophy-section">
    <h2>Правило 2: AI снижает человеческий фактор</h2>
    <blockquote>
      Люди устают. Забывают. Пропускают детали. <strong>AI — нет.</strong>
    </blockquote>

    <div class="two-columns">
      <div class="column">
        <h4>Стандартное агентство:</h4>
        <ul>
          <li>Аналитик проверяет конкурентов раз в неделю вручную</li>
          <li>Забывает обновить данные по одному из конкурентов</li>
          <li>Не замечает, что конкурент изменил лендинг</li>
          <li>Узнаёт об акции конкурента через неделю</li>
        </ul>
      </div>

      <div class="column">
        <h4>AI-подход:</h4>
        <ul>
          <li>Анализ конкурентов за минуты, не за дни</li>
          <li>Ни один конкурент не выпадает из поля зрения</li>
          <li>Все изменения фиксируются сразу при повторном сканировании</li>
          <li>Реакция за день, а не за неделю</li>
        </ul>
      </div>
    </div>

    <hr class="section-divider">

    <h3>Что делает AI:</h3>
    <div class="card-glass">
      <ul>
        <li>Собирает данные по ключевым конкурентам</li>
        <li>Анализирует десятки параметров сайта за минуты</li>
        <li>Сравнивает вас с конкурентами по конкретным метрикам</li>
        <li>Находит паттерны, которые человек может пропустить</li>
      </ul>
    </div>

    <h3>Что делают люди:</h3>
    <div class="card-glass">
      <ul>
        <li>Разрабатывают стратегию — AI предлагает данные, мы принимаем решения</li>
        <li>Создают креативы — тексты, дизайн, идеи</li>
        <li>Общаются с вами — эмпатия и доверие</li>
      </ul>
    </div>
  </div>

  <!-- Правило 3 -->
  <div class="philosophy-section">
    <h2>Правило 3: Гибкость под цифры бизнеса</h2>
    <p>Агентства продают «пакеты»: Базовый, Стандарт, Премиум.</p>
    <blockquote>
      <strong>Проблема:</strong> ваш бизнес не вписывается в пакет. У вас другие задачи, другой бюджет, другая конкуренция.
    </blockquote>

    <h3>Наш подход:</h3>
    <div class="card-glass">
      <ol>
        <li>Смотрим на текущие показатели — трафик, конверсии, LTV</li>
        <li>Ставим цели в цифрах — не «больше клиентов», а «+30% заявок за квартал»</li>
        <li>AI быстро собирает и анализирует данные — решения принимаются быстрее</li>
        <li>Реагируем на изменения оперативно — CTR упал → корректируем креативы за день</li>
      </ol>
    </div>

    <blockquote>
      <strong>Результат:</strong> вы платите за результат, а не за «работы выполнены».
    </blockquote>
  </div>

  <!-- Переломный момент -->
  <div class="philosophy-section">
    <h2>Почему сейчас критично</h2>
    <p><span class="accent-text">2026-2027 — переломный момент.</span></p>

    <div class="two-columns">
      <div class="column">
        <h4>Лагерь 1: Те, кто внедрил AI</h4>
        <ul>
          <li>Получают данные быстрее — решения принимаются раньше конкурентов</li>
          <li>Реагируют на изменения за день, а не за неделю</li>
          <li>Тратят меньше на рекламу — лучше таргетинг, меньше слива бюджета</li>
        </ul>
      </div>

      <div class="column">
        <h4>Лагерь 2: Те, кто работает по-старому</h4>
        <ul>
          <li>Ждут неделями, пока аналитик соберёт данные</li>
          <li>Узнают об изменениях рынка с опозданием</li>
          <li>Тратят больше на те же результаты</li>
        </ul>
      </div>
    </div>

    <blockquote>
      <strong>Разрыв растёт с каждым месяцем.</strong><br>
      Каждое обновление AI-моделей, каждый новый инструмент увеличивает преимущество тех, кто их использует. И увеличивает отставание тех, кто нет.
    </blockquote>

    <p><strong>Почему?</strong> AI учится. Каждый месяц выходят новые модели, новые инструменты. Кто внедряет их первыми, получает преимущество.</p>
  </div>

  <!-- FAQ -->
  <div class="philosophy-section">
    <h2>Честные ответы на неудобные вопросы</h2>

    <div class="faq-item">
      <h3>«Маркетологи скоро не нужны?»</h3>
      <blockquote>
        Нет. Нужны <strong>умные маркетологи</strong>, которые используют AI как инструмент.
      </blockquote>
      <p>Тупая работа (собрать данные, свести в Excel, сделать отчёт) → AI<br>
      Умная работа (стратегия, креатив, переговоры) → люди</p>
      <p>Когда появились калькуляторы, математики не исчезли. Исчезли счетоводы.</p>
      <p class="accent-text">AI не заменит маркетологов. Он заменит тех, кто не использует AI.</p>
    </div>

    <div class="faq-item">
      <h3>«AI лучше людей?»</h3>
      <p><span class="accent-text">В рутине — да. В творчестве — нет.</span></p>
      <p>AI проанализирует сайты конкурентов за минуты. Найдёт паттерны, которые человек пропустит за неделю ручной работы.</p>
      <p>Но AI не придумает цепляющий слоган. Не выстроит доверие с клиентом на встрече. Не поймёт, что у владельца клиники сейчас кассовый разрыв и ему критично получить результат за месяц, а не за квартал.</p>
      <blockquote>
        Мы не выбираем «или-или». Мы делаем «и»: <strong>AI + люди = максимальная эффективность.</strong>
      </blockquote>
    </div>

    <div class="faq-item">
      <h3>«Все перейдут на AI, преимущество исчезнет?»</h3>
      <p>Частично правда.</p>
      <p>AI-инструменты станут массовыми. Через пару лет большинство компаний будут использовать AI для рутины.</p>
      <blockquote>
        <strong>Но.</strong> Есть разница между «используем ChatGPT иногда» и «построили систему, где AI — часть процесса».
      </blockquote>
      <div class="card-glass">
        <p><strong>Разница — как между калькулятором и компьютером.</strong></p>
        <p>Оба считают. Но один — инструмент для одной задачи, второй — платформа для всего бизнеса.</p>
      </div>
    </div>

    <div class="faq-item">
      <h3>«Почему AI, а не просто хорошие маркетологи?»</h3>
      <p>Хорошие маркетологи стоят дорого. Но даже лучшие работают с ограниченной скоростью.</p>
      <p>AI не заменяет людей. Он освобождает их от рутины.</p>
      <div class="card-glass">
        <p><strong>Без AI:</strong> Аналитик тратит 80% времени на сбор данных, 20% на анализ и выводы.</p>
        <p><strong>С AI:</strong> Аналитик тратит 20% времени на проверку данных (AI собрал), 80% на анализ и стратегию.</p>
      </div>
    </div>
  </div>

  <!-- Сравнение -->
  <div class="philosophy-section">
    <h2>Сравнение: Обычное агентство vs AIM</h2>

    <table class="comparison-table">
      <thead>
        <tr>
          <th></th>
          <th>Обычное агентство</th>
          <th>AIM (AI-first)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Анализ конкурентов</strong></td>
          <td>Неделя, вручную</td>
          <td>Автоматически за минуты, без пропусков</td>
        </tr>
        <tr>
          <td><strong>Аудит сайта</strong></td>
          <td>Несколько дней, руками</td>
          <td>Автоматически, десятки параметров</td>
        </tr>
        <tr>
          <td><strong>Время до КП</strong></td>
          <td>2-3 недели</td>
          <td>1-2 дня</td>
        </tr>
        <tr>
          <td><strong>Скорость реакции</strong></td>
          <td>Неделя-две</td>
          <td>День</td>
        </tr>
        <tr>
          <td><strong>Человеческий фактор</strong></td>
          <td>Пропуски, забывания, усталость</td>
          <td>Минимизирован — AI не устаёт</td>
        </tr>
        <tr>
          <td><strong>Стоимость</strong></td>
          <td>Оплата за процесс</td>
          <td>Оплата за результат</td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Final CTA -->
  <div class="cta-box">
    <h3>Следующий шаг</h3>
    <p>Оставьте URL вашего сайта.</p>
    <p>AI сделает экспресс-анализ: технический аудит сайта, анализ конкурентов в вашем регионе, рекомендации по первым шагам.</p>
    <p><strong>Это бесплатно. Это займёт около часа. Это даст вам понимание, где вы сейчас относительно конкурентов.</strong></p>
    <a href="#" class="btn-primary" onclick="window.openChat?.(); return false;">Начать анализ →</a>
  </div>

  <!-- Final Punch -->
  <div class="final-punch">
    Вопрос не «внедрять ли AI?»<br>
    Вопрос: «Успеете ли вы до того, как конкуренты начнут зарабатывать больше вас?»
  </div>

</div>

<?php get_footer(); ?>
