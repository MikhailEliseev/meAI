<?php
get_header();
?>

<!-- Using theme fonts: Jost + Playfair Display (loaded by header.php) -->


<style>
/* ============================================
   DESIGN TOKENS — Nexus Design System
   Medical palette: teal accent + warm beige
   ============================================ */

:root {
  /* Colors — Light (AIM Monochrome) */
  --bg: #ffffff;
  --surface: #F5F5F5;
  --card-bg: #F5F5F5;
  --card-hover: #EBEBEB;
  --text: #1A1A1A;
  --text-secondary: #666666;
  --text-dim: #999999;
  --accent: #1A1A1A;
  --accent-hover: #333333;
  --accent-light: rgba(0,0,0,0.06);
  --accent-glow: rgba(0,0,0,0.10);
  --border: #E0E0E0;
  --border-strong: #CFCFCF;
  --error: #d93025;
  --error-bg: #fce8e6;
  --success: #0d8040;
  --success-bg: #e6f4ea;
  --warning: #e37400;
  --warning-bg: #fef7e0;
  --lock-bg: rgba(0,0,0,0.03);
  --lock-border: rgba(0,0,0,0.12);

  /* Spacing */
  --space-xs: 4px;
  --space-sm: 8px;
  --space-md: 16px;
  --space-lg: 24px;
  --space-xl: 32px;
  --space-2xl: 48px;
  --space-3xl: 64px;

  /* Typography */
  --font-body: 'Jost', sans-serif;
  --font-display: 'Playfair Display', serif;
  --text-xs: 0.75rem;
  --text-sm: 0.875rem;
  --text-base: 1rem;
  --text-lg: 1.125rem;
  --text-xl: 1.5rem;
  --text-2xl: 2rem;
  --text-3xl: 2.5rem;
  --text-4xl: 3.5rem;

  /* Radii */
  --radius-sm: 6px;
  --radius-md: 10px;
  --radius-lg: 16px;
  --radius-xl: 24px;

  /* Shadows */
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.04);
  --shadow-md: 0 4px 12px rgba(0,0,0,0.06);
  --shadow-lg: 0 8px 24px rgba(0,0,0,0.08);
  --shadow-xl: 0 16px 48px rgba(0,0,0,0.10);
  --shadow-glow: 0 0 0 3px var(--accent-glow);

  /* Transitions */
  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
  --ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);
  --duration-fast: 150ms;
  --duration-base: 250ms;
  --duration-slow: 400ms;
}

[data-theme="dark"] {
  --bg: #0d0d0d;
  --surface: #1a1a1a;
  --card-bg: #1a1a1a;
  --card-hover: rgba(201,169,110,.05);
  --text: #f5f0e8;
  --text-secondary: #9e9489;
  --text-dim: #7a7268;
  --accent: #c9a96e;
  --accent-hover: #e8cfa0;
  --accent-light: rgba(201,169,110,0.1);
  --accent-glow: rgba(201,169,110,0.15);
  --border: rgba(201,169,110,.18);
  --border-strong: rgba(201,169,110,.35);
  --error: #f28b82;
  --error-bg: rgba(242,139,130,0.12);
  --success: #81c995;
  --success-bg: rgba(129,201,149,0.12);
  --warning: #fdd663;
  --warning-bg: rgba(253,214,99,0.12);
  --lock-bg: rgba(201,169,110,0.05);
  --lock-border: rgba(201,169,110,0.2);
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.2);
  --shadow-md: 0 4px 12px rgba(0,0,0,0.3);
  --shadow-lg: 0 8px 24px rgba(0,0,0,0.4);
  --shadow-xl: 0 16px 48px rgba(0,0,0,0.5);
}

/* ============================================
   RESET & BASE
   ============================================ */

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  font-size: 16px;
  scroll-behavior: smooth;
}

body {
  font-family: var(--font-body);
  font-size: var(--text-base);
  line-height: 1.6;
  color: var(--text);
  background: var(--bg);
  min-height: 100vh;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  transition: background var(--duration-base) var(--ease-out),
              color var(--duration-base) var(--ease-out);
}

/* Skip link */
/* Prevent horizontal overflow */
.calc-scope { overflow-x: clip; }

.skip-link {
  position: absolute;
  top: -100%;
  left: var(--space-md);
  background: var(--accent);
  color: #fff;
  padding: var(--space-sm) var(--space-md);
  border-radius: var(--radius-sm);
  z-index: 1000;
  font-weight: 500;
  text-decoration: none;
}
.skip-link:focus {
  top: var(--space-md);
}

/* ============================================
   HEADER
   ============================================ */

/* ============================================
   LAYOUT
   ============================================ */

main {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 var(--space-xl) var(--space-3xl);
}

.layout {
  display: grid;
  grid-template-columns: 1fr 380px;
  gap: var(--space-xl);
  align-items: start;
}

.content {
  min-width: 0;
}

/* ============================================
   PROGRESS INDICATOR
   ============================================ */

.progress {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0;
  margin-bottom: var(--space-2xl);
  padding: var(--space-lg) 0;
}

.progress-step {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
  color: var(--text-dim);
  font-size: var(--text-sm);
  font-weight: 500;
  transition: color var(--duration-base) var(--ease-out);
  white-space: nowrap;
}

.progress-step .step-icon {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--text-sm);
  font-weight: 700;
  background: var(--border);
  color: var(--text-dim);
  transition: all var(--duration-base) var(--ease-out);
  flex-shrink: 0;
}

.progress-step.active {
  color: var(--accent);
}
.progress-step.active .step-icon {
  background: var(--accent);
  color: #fff;
  box-shadow: var(--shadow-glow);
}

.progress-step.done {
  color: var(--accent);
}
.progress-step.done .step-icon {
  background: var(--accent-light);
  color: var(--accent);
}

.progress-line {
  width: 40px;
  height: 2px;
  background: var(--border);
  margin: 0 var(--space-sm);
  transition: background var(--duration-base) var(--ease-out);
  flex-shrink: 0;
}
.progress-line.done {
  background: var(--accent);
}

@media (max-width: 768px) {
  .progress {
    gap: var(--space-xs);
    margin-bottom: var(--space-lg);
    padding: var(--space-md) 0;
  }
  .progress-step {
    font-size: var(--text-xs);
    gap: 4px;
  }
  .progress-step .step-icon {
    width: 28px;
    height: 28px;
    font-size: var(--text-xs);
  }
  .progress-line {
    width: 16px;
    margin: 0 2px;
  }
}

/* ============================================
   STEP CONTAINER
   ============================================ */

.step {
  display: none;
  animation: stepIn var(--duration-slow) var(--ease-out);
}
.step.active {
  display: block;
}

@keyframes stepIn {
  from { opacity: 0; transform: translateX(20px); }
  to   { opacity: 1; transform: translateX(0); }
}
@keyframes stepOut {
  from { opacity: 1; transform: translateX(0); }
  to   { opacity: 0; transform: translateX(-20px); }
}

/* ============================================
   FORM ELEMENTS BASE
   ============================================ */

label {
  display: block;
  font-weight: 500;
  font-size: var(--text-sm);
  color: var(--text);
  margin-bottom: var(--space-xs);
}

select, input[type="number"], input[type="text"], input[type="tel"] {
  width: 100%;
  padding: 10px 14px;
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  background: var(--surface);
  color: var(--text);
  font-family: var(--font-body);
  font-size: var(--text-base);
  transition: all var(--duration-fast) var(--ease-out);
  outline: none;
}
select:focus, input:focus {
  border-color: var(--accent);
  box-shadow: var(--shadow-glow);
}

.field {
  margin-bottom: var(--space-lg);
}

.field-hint {
  font-size: var(--text-xs);
  color: var(--text-dim);
  margin-top: var(--space-xs);
}

/* ============================================
   BUTTONS
   ============================================ */

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-sm);
  padding: 12px 28px;
  border: none;
  border-radius: var(--radius-md);
  font-family: var(--font-body);
  font-size: var(--text-base);
  font-weight: 600;
  cursor: pointer;
  transition: all var(--duration-fast) var(--ease-out);
  position: relative;
  overflow: hidden;
}

.btn-primary {
  background: var(--accent);
  color: #fff;
}
.btn-primary:hover {
  background: var(--accent-hover);
  transform: translateY(-1px);
  box-shadow: var(--shadow-md);
}

.btn-secondary {
  background: var(--surface);
  color: var(--text);
  border: 1px solid var(--border);
}
.btn-secondary:hover {
  border-color: var(--accent);
  color: var(--accent);
}

.btn-large {
  width: 100%;
  padding: 16px 32px;
  font-size: var(--text-lg);
}

/* Ripple */
.btn::after {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at center, rgba(255,255,255,0.3) 0%, transparent 70%);
  opacity: 0;
  transition: opacity var(--duration-fast);
}
.btn:active::after {
  opacity: 1;
}

.step-nav {
  display: flex;
  justify-content: space-between;
  gap: var(--space-md);
  margin-top: var(--space-xl);
}

/* ============================================
   MODULE CARD
   ============================================ */

.module-card {
  background: var(--card-bg);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: var(--space-lg);
  margin-bottom: var(--space-md);
  transition: all var(--duration-base) var(--ease-out);
  cursor: pointer;
  position: relative;
}

.module-card:hover {
  border-color: var(--border-strong);
  box-shadow: var(--shadow-md);
  transform: translateY(-2px);
}

.module-card.active {
  background: var(--accent-light);
  border: 2px solid var(--accent);
  box-shadow: var(--shadow-glow);
}

.module-card.active:hover {
  transform: none;
}

.module-card input[type="checkbox"] {
  position: absolute;
  opacity: 0;
  pointer-events: none;
}

.module-card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-md);
}

.module-card-info {
  flex: 1;
  min-width: 0;
}

.module-card-title {
  font-weight: 600;
  font-size: var(--text-base);
  color: var(--text);
  margin-bottom: 2px;
  overflow-wrap: break-word;
  word-break: break-word;
}

.module-card-desc {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  line-height: 1.4;
  overflow-wrap: break-word;
  word-break: break-word;
}

.module-card-price {
  text-align: right;
  flex-shrink: 0;
  display: flex;
  align-items: baseline;
  gap: 4px;
}

.module-card-price .price-value {
  font-weight: 700;
  font-size: var(--text-lg);
  color: var(--text);
  white-space: nowrap;
}
.module-card-price .price-label {
  font-size: var(--text-xs);
  color: var(--text-dim);
  white-space: nowrap;
}

.module-card.active .module-card-price .price-value {
  color: var(--accent);
}

/* Expandable details */
.module-card-footer {
  margin-top: var(--space-md);
  padding-top: var(--space-md);
  border-top: 1px solid var(--border);
}

.details-toggle {
  display: inline-flex;
  align-items: center;
  gap: var(--space-xs);
  font-size: var(--text-sm);
  color: var(--accent);
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  font-family: var(--font-body);
  font-weight: 500;
  transition: opacity var(--duration-fast) var(--ease-out);
}

.details-toggle:hover {
  opacity: 0.7;
}

.details-toggle-icon {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: 2px solid var(--accent);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 700;
  transition: transform var(--duration-base) var(--ease-out),
              background var(--duration-base) var(--ease-out);
  transform: rotate(0deg);
}

.details-toggle.open .details-toggle-icon {
  transform: rotate(0deg);
  background: var(--accent);
  color: white;
}

.module-details {
  max-height: 0;
  overflow: hidden;
  opacity: 0;
  transition: max-height var(--duration-slow) var(--ease-out),
              opacity var(--duration-base) var(--ease-out),
              margin var(--duration-base) var(--ease-out);
  margin-top: 0;
}

.module-details.open {
  max-height: 500px;
  opacity: 1;
  margin-top: var(--space-md);
}

.module-details-content {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  line-height: 1.6;
}

.module-details-content ul {
  list-style: none;
  padding: 0;
  margin: var(--space-sm) 0 0 0;
}

.module-details-content li {
  padding: var(--space-xs) 0;
  padding-left: var(--space-md);
  position: relative;
}

.module-details-content li:before {
  content: '•';
  position: absolute;
  left: 0;
  color: var(--accent);
  font-weight: 700;
}

/* ============================================
   SUMMARY PANEL
   ============================================ */

.summary-panel {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: var(--space-lg);
  position: sticky;
  top: 80px;
  box-shadow: var(--shadow-lg);
  transition: all var(--duration-base) var(--ease-out);
}

.summary-panel h3 {
  font-family: var(--font-body);
  font-size: var(--text-sm);
  font-weight: 600;
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: var(--space-sm);
}

.summary-total {
  font-family: var(--font-display);
  font-size: var(--text-4xl);
  font-weight: 400;
  color: var(--accent);
  line-height: 1.1;
  transition: color var(--duration-base) var(--ease-out);
}

.summary-total.animating {
  animation: pulse 300ms var(--ease-out);
}

@keyframes pulse {
  0%   { transform: scale(1); }
  50%  { transform: scale(1.04); }
  100% { transform: scale(1); }
}

.summary-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  margin-bottom: var(--space-lg);
}

.summary-selected {
  margin-top: var(--space-lg);
  padding-top: var(--space-md);
  border-top: 1px solid var(--border);
}

.summary-selected h4 {
  font-size: var(--text-xs);
  font-weight: 600;
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: var(--space-sm);
}

.summary-selected-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 6px 0;
  font-size: var(--text-sm);
  color: var(--text);
}

.summary-selected-item .item-name {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
}

.summary-selected-item .item-check {
  color: var(--accent);
  font-weight: 700;
}

.summary-selected-item .item-price {
  font-weight: 600;
  white-space: nowrap;
}

.summary-cta {
  margin-top: var(--space-lg);
}

/* ============================================
   STEP 3 — TABLE
   ============================================ */

.breakdown-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: var(--space-lg);
}

.breakdown-table th,
.breakdown-table td {
  padding: 10px 14px;
  text-align: left;
  border-bottom: 1px solid var(--border);
  font-size: var(--text-sm);
}

.breakdown-table th {
  font-weight: 600;
  color: var(--text-dim);
  font-size: var(--text-xs);
  text-transform: uppercase;
  letter-spacing: 0.03em;
}

.breakdown-table td {
  color: var(--text);
}

.breakdown-table .price-cell {
  text-align: right;
  font-weight: 600;
  white-space: nowrap;
}

.breakdown-table .total-row td {
  border-bottom: none;
  font-weight: 700;
  font-size: var(--text-lg);
  color: var(--accent);
  font-family: var(--font-display);
}

.total-fee-display {
  font-family: var(--font-display);
  font-size: var(--text-4xl);
  color: var(--accent);
  text-align: center;
  margin: var(--space-lg) 0;
  line-height: 1.1;
}

.total-fee-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  text-align: center;
  margin-bottom: var(--space-sm);
}

/* ============================================
   FORM
   ============================================ */

.contact-form {
  margin-top: var(--space-xl);
  padding-top: var(--space-xl);
  border-top: 1px solid var(--border);
}

.contact-form h3 {
  font-family: var(--font-body);
  font-size: var(--text-lg);
  font-weight: 600;
  margin-bottom: var(--space-lg);
  color: var(--text);
}

.form-group {
  margin-bottom: var(--space-md);
}

.form-group label {
  font-weight: 500;
  font-size: var(--text-sm);
  margin-bottom: var(--space-xs);
}

.form-group input {
  width: 100%;
  padding: 12px 14px;
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  background: var(--surface);
  color: var(--text);
  font-family: var(--font-body);
  font-size: var(--text-base);
  outline: none;
  transition: all var(--duration-fast) var(--ease-out);
}

.form-group input:focus {
  border-color: var(--accent);
  box-shadow: var(--shadow-glow);
}

.form-group input.error {
  border-color: var(--error);
  box-shadow: 0 0 0 3px rgba(217, 48, 37, 0.1);
}

.form-error {
  font-size: var(--text-xs);
  color: var(--error);
  margin-top: var(--space-xs);
  display: none;
}
.form-error.visible { display: block; }

.contact-method-group {
  display: flex;
  gap: var(--space-sm);
  flex-wrap: wrap;
}

.radio-chip {
  position: relative;
}

.radio-chip input {
  position: absolute;
  opacity: 0;
  pointer-events: none;
}

.radio-chip label {
  display: inline-flex;
  align-items: center;
  padding: 8px 16px;
  border: 1px solid var(--border);
  border-radius: var(--radius-xl);
  background: var(--surface);
  font-size: var(--text-sm);
  font-weight: 500;
  cursor: pointer;
  transition: all var(--duration-fast) var(--ease-out);
  margin: 0;
  user-select: none;
}

.radio-chip input:checked + label {
  background: var(--accent-light);
  border-color: var(--accent);
  color: var(--accent);
}

.radio-chip label:hover {
  border-color: var(--accent);
}

/* Success screen */
.success-screen {
  display: none;
  text-align: center;
  padding: var(--space-3xl) var(--space-xl);
  animation: stepIn var(--duration-slow) var(--ease-out);
}
.success-screen.visible { display: block; }

.success-icon {
  width: 80px;
  height: 80px;
  margin: 0 auto var(--space-lg);
}

.success-icon svg {
  width: 100%;
  height: 100%;
}

.success-check {
  stroke: var(--success);
  stroke-width: 3;
  fill: none;
  stroke-dasharray: 100;
  stroke-dashoffset: 100;
  animation: drawCheck 600ms var(--ease-out) 200ms forwards;
}

@keyframes drawCheck {
  to { stroke-dashoffset: 0; }
}

.success-screen h3 {
  font-family: var(--font-display);
  font-size: var(--text-2xl);
  color: var(--text);
  margin-bottom: var(--space-sm);
}

.success-screen p {
  color: var(--text-secondary);
  font-size: var(--text-base);
  margin-bottom: var(--space-lg);
}

/* ============================================
   FOOTER
   ============================================ */

footer {
  text-align: center;
  padding: var(--space-lg);
  color: var(--text-dim);
  font-size: var(--text-xs);
  border-top: 1px solid var(--border);
  margin-top: var(--space-3xl);
}

/* ============================================
   RESPONSIVE
   ============================================ */

@media (max-width: 1023px) {
  .layout {
    grid-template-columns: 1fr;
  }

  .summary-panel {
    position: static;
    border-radius: var(--radius-lg) var(--radius-lg) 0 0;
  }

  .summary-total {
    font-size: var(--text-2xl);
  }

  main {
    padding-bottom: 100px;
  }
}

@media (max-width: 767px) {
  :root {
    --text-4xl: 2.5rem;
  }

  header {
    padding: var(--space-md);
  }

  main {
    padding: 0 var(--space-md) 120px;
  }

  .layout {
    gap: var(--space-md);
  }

  .summary-panel {
    position: fixed;
    top: auto;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 40;
    border-radius: var(--radius-lg) var(--radius-lg) 0 0;
    padding: var(--space-md);
    box-shadow: var(--shadow-xl);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-md);
  }

  .summary-panel h3,
  .summary-panel .summary-label,
  .summary-panel .summary-selected { display: none; }

  .summary-panel .summary-total {
    font-size: var(--text-xl);
  }

  .summary-panel .summary-cta {
    margin-top: 0;
    flex-shrink: 0;
  }

  .summary-panel .summary-cta .btn {
    padding: 10px 20px;
    font-size: var(--text-sm);
  }

  .summary-mobile-row {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    width: 100%;
  }

  .summary-mobile-price {
    display: flex;
    flex-direction: column;
  }

  .summary-mobile-price .summary-total {
    line-height: 1;
  }

  .summary-mobile-price .summary-label {
    display: block !important;
    font-size: var(--text-xs);
    margin: 0;
  }

  .step-nav {
    flex-direction: column;
    gap: var(--space-sm);
  }

  .breakdown-table {
    font-size: var(--text-xs); display: block; overflow-x: auto; -webkit-overflow-scrolling: touch;
  }

  .breakdown-table th,
  .breakdown-table td {
    padding: 8px 10px;
  }
}

@media (min-width: 768px) and (max-width: 1023px) {
  .summary-mobile-row { display: block; }
}

@media (min-width: 768px) {
  .summary-mobile-price .summary-label { display: none !important; }
}

/* ============================================
   REDUCED MOTION
   ============================================ */

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
</style>

<div class="calc-scope">
<a href="#main-content" class="skip-link">Пропустить навигацию</a>

<main id="main-content">
  <!-- Progress Indicator -->
  <div class="progress" role="navigation" aria-label="Шаги калькулятора">
    <div class="progress-step active" data-step="1">
      <div class="step-icon">1</div>
      <span>Каналы</span>
    </div>
    <div class="progress-line" data-line="1"></div>
    <div class="progress-step" data-step="2">
      <div class="step-icon">2</div>
      <span>Допы</span>
    </div>
    <div class="progress-line" data-line="2"></div>
    <div class="progress-step" data-step="3">
      <div class="step-icon">3</div>
      <span>Итог</span>
    </div>
  </div>

  <div class="layout">
    <div class="content">

      <!-- ===== STEP 1: Channels ===== -->
      <div class="step active" id="step1" role="tabpanel" aria-label="Шаг 1: Каналы">
        <h2 style="font-weight:600;font-size:var(--text-xl);margin-bottom:var(--space-lg)">Выберите каналы продвижения</h2>

        <!-- base — always on -->
        <div class="module-card active" id="card-base" style="cursor:default">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">Мониторинг маркетинговых показателей</div>
              <div class="module-card-desc">Мониторинг ваших показателей на фоне 3 основных конкурентов</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">24 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div style="font-size:var(--text-xs);color:var(--accent);margin-top:var(--space-sm);font-weight:500">✓ Обязательный модуль</div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-base" onclick="toggleDetails(event, 'base')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-base">
              <div class="module-details-content">
                <ul>
                  <li>Еженедельный мониторинг 3 основных конкурентов</li>
                  <li>Отслеживание цен конкурентов</li>
                  <li>Мониторинг отзывов конкурентов</li>
                  <li>Отслеживание докторов конкурентов (кто добавляется/уходит)</li>
                  <li>Мониторинг ваших позиций в поисковых системах</li>
                  <li>Настройка и подключение Яндекс.Метрики, Google Analytics</li>
                  <li>Дашборды с ключевыми показателями</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- seo_geo -->
        <div class="module-card" id="card-seo_geo" data-module="seo_geo">
          <input type="checkbox" id="mod-seo_geo">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">SEO + GEO продвижение</div>
              <div class="module-card-desc">Продвижение сайта клиники, гео-запросы, работа с семантикой</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">56 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-seo_geo" onclick="toggleDetails(event, 'seo_geo')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-seo_geo">
              <div class="module-details-content">
                <ul>
                  <li>Сбор и анализ семантического ядра</li>
                  <li>Техническая оптимизация сайта</li>
                  <li>Оптимизация контента под поисковые запросы</li>
                  <li>Продвижение по гео-запросам (город, район)</li>
                  <li>Работа с внешними ссылками</li>
                  <li>Анализ конкурентов и стратегия продвижения</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- tech_support -->
        <div class="module-card" id="card-tech_support" data-module="tech_support">
          <input type="checkbox" id="mod-tech_support">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">Техподдержка</div>
              <div class="module-card-desc">Техническая поддержка сайта, исправление ошибок, обновления</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">19 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-tech_support" onclick="toggleDetails(event, 'tech_support')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-tech_support">
              <div class="module-details-content">
                <ul>
                  <li>Исправление технических ошибок на сайте</li>
                  <li>Обновление CMS и плагинов</li>
                  <li>Резервное копирование данных</li>
                  <li>Мониторинг доступности и скорости сайта</li>
                  <li>Консультации по техническим вопросам</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- performance -->
        <div class="module-card" id="card-performance" data-module="performance">
          <input type="checkbox" id="mod-performance">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">Performance-маркетинг</div>
              <div class="module-card-desc">Запуск и ведение рекламных кампаний</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">19 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-performance" onclick="toggleDetails(event, 'performance')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-performance">
              <div class="module-details-content">
                <ul>
                  <li>Настройка и запуск рекламных кампаний в Яндекс.Директ</li>
                  <li>Разработка рекламных объявлений и креативов</li>
                  <li>A/B-тестирование объявлений</li>
                  <li>Оптимизация ставок и бюджета</li>
                  <li>Еженедельная оптимизация кампаний</li>
                  <li>Отчёты по эффективности рекламы</li>
                </ul>
                <p style="margin-top:var(--space-sm);font-size:var(--text-xs);font-style:italic;">* Рекламный бюджет оплачивается отдельно</p>
              </div>
            </div>
          </div>
        </div>

        <!-- maps -->
        <div class="module-card" id="card-maps" data-module="maps">
          <input type="checkbox" id="mod-maps">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">Карты + агрегаторы + поведенческий</div>
              <div class="module-card-desc">Яндекс/Google Карты, Продокторов, работа с отзывами, поведенческие активности</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">34 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-maps" onclick="toggleDetails(event, 'maps')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-maps">
              <div class="module-details-content">
                <ul>
                  <li>Оптимизация профилей в Яндекс.Картах и Google Maps</li>
                  <li>Ведение профиля на ПроДокторов и других агрегаторах</li>
                  <li>Работа с отзывами: ответы, модерация</li>
                  <li>Поведенческие активности для улучшения позиций</li>
                  <li>Регулярное добавление фото, актуализация информации</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- smm -->
        <div class="module-card" id="card-smm" data-module="smm">
          <input type="checkbox" id="mod-smm">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">SMM (VK + Instagram)</div>
              <div class="module-card-desc">Контент-планы, разработка постов, постинг</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">59 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-smm" onclick="toggleDetails(event, 'smm')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-smm">
              <div class="module-details-content">
                <ul>
                  <li>Разработка контент-плана на месяц</li>
                  <li>Стандартное создание дизайна постов (до 20 постов/мес)</li>
                  <li>Написание текстов для постов</li>
                  <li>Публикация постов по расписанию</li>
                  <li>Ответы на комментарии и сообщения</li>
                  <li>Ведение 2 площадок: VK и Instagram</li>
                  <li>Подключение сервисов автоворонок</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- messengers -->
        <div class="module-card" id="card-messengers" data-module="messengers">
          <input type="checkbox" id="mod-messengers">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">Мессенджеры и каналы</div>
              <div class="module-card-desc">Ведение каналов в WhatsApp и Telegram</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">49 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-messengers" onclick="toggleDetails(event, 'messengers')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-messengers">
              <div class="module-details-content">
                <ul>
                  <li>Разработка контент-плана для мессенджеров</li>
                  <li>Стандартное создание контента для публикаций</li>
                  <li>Ведение Telegram-канала клиники</li>
                  <li>Ведение WhatsApp-канала</li>
                  <li>Публикация по расписанию</li>
                  <li>Подключение сервисов автоворонок</li>
                  <li>Аналитика эффективности каналов</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- ai_bots -->
        <div class="module-card" id="card-ai_bots" data-module="ai_bots">
          <input type="checkbox" id="mod-ai_bots">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">AI-продавцы / AI-боты</div>
              <div class="module-card-desc">Автоответы, запись пациентов, квалификация лидов</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">34 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-ai_bots" onclick="toggleDetails(event, 'ai_bots')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-ai_bots">
              <div class="module-details-content">
                <ul>
                  <li>Настройка AI-бота для автоответов на сайте и в мессенджерах</li>
                  <li>Обучение бота на базе знаний клиники</li>
                  <li>Автоматическая запись пациентов к врачам</li>
                  <li>Квалификация лидов и передача менеджеру</li>
                  <li>Интеграция с CRM и календарём записи</li>
                  <li>Постоянное улучшение и дообучение бота</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div class="step-nav">
          <div></div>
          <button class="btn btn-primary" id="toStep2">Далее →</button>
        </div>
      </div>

      <!-- ===== STEP 2: Extras ===== -->
      <div class="step" id="step2" role="tabpanel" aria-label="Шаг 2: Дополнительные услуги">
        <h2 style="font-weight:600;font-size:var(--text-xl);margin-bottom:var(--space-lg)">Дополнительные услуги</h2>

        <!-- grey_seo -->
        <div class="module-card" id="card-grey_seo" data-module="grey_seo">
          <input type="checkbox" id="mod-grey_seo">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">«Непопулярное» SEO</div>
              <div class="module-card-desc">Агрессивные методы продвижения</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">89 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-grey_seo" onclick="toggleDetails(event, 'grey_seo')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-grey_seo">
              <div class="module-details-content">
                <ul>
                  <li>Агрессивные методы наращивания ссылочной массы</li>
                  <li>Работа с дорвеями и PBN-сетками</li>
                  <li>Скрытые тексты и doorway-страницы</li>
                  <li>Быстрое продвижение по высококонкурентным запросам</li>
                  <li>Консультации по рискам и стратегии применения</li>
                </ul>
                <p style="margin-top:var(--space-sm);font-size:var(--text-xs);font-style:italic;color:var(--warning);">⚠️ Методы связаны с рисками санкций от поисковых систем</p>
              </div>
            </div>
          </div>
        </div>

        <!-- neuro_content -->
        <div class="module-card" id="card-neuro_content" data-module="neuro_content">
          <input type="checkbox" id="mod-neuro_content">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">Генерация креативов и фото-видео контента</div>
              <div class="module-card-desc">Нейровидео по сценарию, цифровые аватары, нейрофотосессии (15 шт/мес)</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">79 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-neuro_content" onclick="toggleDetails(event, 'neuro_content')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-neuro_content">
              <div class="module-details-content">
                <ul>
                  <li>Создание нейровидео по сценарию (до 15 роликов/мес)</li>
                  <li>Разработка цифровых аватаров врачей</li>
                  <li>Нейрофотосессии: создание фото с AI</li>
                  <li>Генерация креативов для рекламы</li>
                  <li>Адаптация контента под разные форматы и платформы</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- content_factory -->
        <div class="module-card" id="card-content_factory" data-module="content_factory">
          <input type="checkbox" id="mod-content_factory">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">Контент-завод (мультиаккаунты)</div>
              <div class="module-card-desc">До 50 аккаунтов в Instagram, TikTok, Дзен, VK, Threads</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">99 000 ₽</div>
              <div class="price-label">/мес</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-content_factory" onclick="toggleDetails(event, 'content_factory')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-content_factory">
              <div class="module-details-content">
                <ul>
                  <li>Создание и ведение до 50 аккаунтов в соцсетях</li>
                  <li>Распространение контента через 50 облачных телефонов</li>
                  <li>Массовая генерация контента с помощью AI</li>
                  <li>Автопостинг по расписанию</li>
                  <li>Охват различных сегментов аудитории</li>
                  <li>Создание сети лояльных аккаунтов для поддержки основного бренда</li>
                  <li>Аналитика по всем аккаунтам</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- callcenter -->
        <div class="module-card" id="card-callcenter" data-module="callcenter">
          <input type="checkbox" id="mod-callcenter">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">Анализ колл-центра и прослушка звонков</div>
              <div class="module-card-desc">Разовая услуга: анализ работы колл-центра, прослушка записей звонков</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">49 000 ₽</div>
              <div class="price-label">разово</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-callcenter" onclick="toggleDetails(event, 'callcenter')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-callcenter">
              <div class="module-details-content">
                <ul>
                  <li>Прослушка записей звонков (до 100 звонков)</li>
                  <li>Анализ скриптов продаж и качества обслуживания</li>
                  <li>Оценка конверсии звонок → запись</li>
                  <li>Выявление типичных ошибок операторов</li>
                  <li>Рекомендации по улучшению работы колл-центра</li>
                  <li>Разработка скриптов и чек-листов для операторов</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- website_redesign -->
        <div class="module-card" id="card-website_redesign" data-module="website_redesign">
          <input type="checkbox" id="mod-website_redesign">
          <div class="module-card-header">
            <div class="module-card-info">
              <div class="module-card-title">Полная переработка сайта на CMS</div>
              <div class="module-card-desc">Редизайн и перенос на 1С-Битрикс или WordPress</div>
            </div>
            <div class="module-card-price">
              <div class="price-value">от 250 000 ₽</div>
              <div class="price-label">разово</div>
            </div>
          </div>
          <div class="module-card-footer">
            <button class="details-toggle" data-target="details-website_redesign" onclick="toggleDetails(event, 'website_redesign')">
              <span class="details-toggle-icon">?</span>
              <span>Что входит в услугу</span>
            </button>
            <div class="module-details" id="details-website_redesign">
              <div class="module-details-content">
                <ul>
                  <li>Аудит текущего сайта и анализ потребностей</li>
                  <li>Разработка нового дизайна и структуры</li>
                  <li>Вёрстка и адаптация под все устройства</li>
                  <li>Перенос контента на новую CMS (1С-Битрикс или WordPress)</li>
                  <li>Настройка SEO-параметров и технической оптимизации</li>
                  <li>Интеграция с внешними сервисами (CRM, аналитика, формы)</li>
                  <li>Тестирование и запуск</li>
                  <li>Обучение администраторов работе с CMS</li>
                </ul>
                <p style="margin-top:var(--space-sm);font-size:var(--text-xs);font-style:italic;">* Стоимость зависит от объёма сайта и сложности функционала</p>
              </div>
            </div>
          </div>
        </div>

        <div class="step-nav">
          <button class="btn btn-secondary" id="backToStep1">← Назад</button>
          <button class="btn btn-primary" id="toStep3">Далее →</button>
        </div>
      </div>

      <!-- ===== STEP 3: Summary & Form ===== -->
      <div class="step" id="step3" role="tabpanel" aria-label="Шаг 3: Итог и заявка">
        <h2 style="font-weight:600;font-size:var(--text-xl);margin-bottom:var(--space-lg)">Ваше персональное решение</h2>

        <div class="total-fee-label">Ежемесячная стоимость</div>
        <div class="total-fee-display" id="finalTotal" aria-live="polite">24 000 ₽</div>

        <!-- Breakdown table -->
        <table class="breakdown-table" id="breakdownTable">
          <thead>
            <tr>
              <th>Услуга</th>
              <th>Стоимость</th>
              <th>Период</th>
            </tr>
          </thead>
          <tbody id="breakdownBody"></tbody>
          <tfoot id="breakdownFoot"></tfoot>
        </table>

        <!-- Contact form -->
        <div class="contact-form" id="contactForm">
          <h3>Отправить заявку</h3>
          <div class="form-group">
            <label for="contactName">Имя *</label>
            <input type="text" id="contactName" placeholder="Иван" required>
            <div class="form-error" id="error-name">Введите имя</div>
          </div>
          <div class="form-group">
            <label for="contactPhone">Телефон *</label>
            <input type="tel" id="contactPhone" placeholder="+7 (___) ___-__-__" required>
            <div class="form-error" id="error-phone">Введите номер телефона</div>
          </div>
          <div class="form-group">
            <label>Связаться через *</label>
            <div class="contact-method-group">
              <div class="radio-chip">
                <input type="radio" name="contactMethod" id="methodTelegram" value="telegram" checked>
                <label for="methodTelegram">Telegram</label>
              </div>
              <div class="radio-chip">
                <input type="radio" name="contactMethod" id="methodWhatsapp" value="whatsapp">
                <label for="methodWhatsapp">WhatsApp</label>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="contactMessenger">Ваш ник *</label>
            <input type="text" id="contactMessenger" placeholder="@username" required>
            <div class="form-error" id="error-messenger">Введите ник</div>
          </div>
          <button class="btn btn-primary btn-large" id="submitForm">Отправить</button>
        </div>

        <!-- Success screen -->
        <div class="success-screen" id="successScreen">
          <div class="success-icon">
            <svg viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="46" stroke="var(--success)" stroke-width="3" fill="none" opacity="0.3"/>
              <path class="success-check" d="M28 52 l16 16 l28-28"/>
            </svg>
          </div>
          <h3>Заявка принята!</h3>
          <p>Мы подготовим персональное КП и свяжемся с вами в ближайшее время.</p>
          <button class="btn btn-secondary" id="resetAll">Начать сначала</button>
        </div>

        <div class="step-nav" style="margin-top:var(--space-lg)">
          <button class="btn btn-secondary" id="backToStep2">← Изменить</button>
          <button class="btn btn-secondary" id="resetFromStep3">Начать сначала</button>
        </div>
      </div>
    </div>

    <!-- ===== SUMMARY PANEL ===== -->
    <aside class="summary-panel" role="complementary" aria-label="Итоговая стоимость">
      <h3>Ваше решение</h3>
      <div class="summary-mobile-row">
        <div class="summary-mobile-price">
          <div class="summary-total" id="summaryTotal" aria-live="polite">24 000 ₽</div>
          <div class="summary-label">стоимость /мес</div>
        </div>
      </div>
      <div class="summary-selected" id="summarySelected">
        <h4>Выбрано</h4>
        <div id="summarySelectedList"></div>
      </div>
      <div class="summary-cta">
        <button class="btn btn-primary btn-large" id="summaryCTA">Оформить заявку →</button>
      </div>
    </aside>
  </div>
</main>

<footer>
  AIM Agency — Маркетинг для медицинских клиник
</footer>

<script>
/* ============================================
   PRICING CONFIG
   ============================================ */

const PRICING_CONFIG = {
  modules: {
    base: {
      id: 'base',
      name: 'Мониторинг маркетинговых показателей',
      price: 24000,
      required: true,
      period: '/мес'
    },
    seo_geo: {
      id: 'seo_geo',
      name: 'SEO + GEO продвижение',
      price: 56000,
      required: false,
      period: '/мес'
    },
    tech_support: {
      id: 'tech_support',
      name: 'Техподдержка',
      price: 19000,
      required: false,
      period: '/мес'
    },
    performance: {
      id: 'performance',
      name: 'Performance-маркетинг',
      price: 19000,
      required: false,
      period: '/мес'
    },
    maps: {
      id: 'maps',
      name: 'Карты + агрегаторы + поведенческий',
      price: 34000,
      required: false,
      period: '/мес'
    },
    smm: {
      id: 'smm',
      name: 'SMM (VK + Instagram)',
      price: 56000,
      required: false,
      period: '/мес'
    },
    messengers: {
      id: 'messengers',
      name: 'Мессенджеры и каналы',
      price: 49000,
      required: false,
      period: '/мес'
    },
    ai_bots: {
      id: 'ai_bots',
      name: 'AI-продавцы / AI-боты',
      price: 34000,
      required: false,
      period: '/мес'
    },
    grey_seo: {
      id: 'grey_seo',
      name: '«Непопулярное» SEO',
      price: 89000,
      required: false,
      period: '/мес'
    },
    neuro_content: {
      id: 'neuro_content',
      name: 'Генерация креативов и фото-видео контента',
      price: 79000,
      required: false,
      period: '/мес'
    },
    content_factory: {
      id: 'content_factory',
      name: 'Контент-завод (50 аккаунтов)',
      price: 99000,
      required: false,
      period: '/мес'
    },
    callcenter: {
      id: 'callcenter',
      name: 'Анализ колл-центра и прослушка',
      price: 49000,
      required: false,
      period: 'разово'
    },
    website_redesign: {
      id: 'website_redesign',
      name: 'Полная переработка сайта на CMS',
      price: 250000,
      required: false,
      period: 'разово'
    }
  }
};

/* ============================================
   STATE
   ============================================ */

const state = {
  currentStep: 1,
  selectedModules: { base: true }
};

/* ============================================
   CALCULATIONS
   ============================================ */

function fmt(n) {
  return n.toLocaleString('ru-RU').replace(/,/g, ' ') + ' ₽';
}

function calculateTotal() {
  let total = 0;
  for (const modId of Object.keys(state.selectedModules)) {
    if (!state.selectedModules[modId]) continue;
    const mod = PRICING_CONFIG.modules[modId];
    if (mod) total += mod.price;
  }
  return total;
}

/* ============================================
   UI HELPERS
   ============================================ */

function updateSummaryPanel() {
  const total = calculateTotal();
  const el = document.getElementById('summaryTotal');
  animateNumber(el, total);

  // Selected items list
  const listEl = document.getElementById('summarySelectedList');
  listEl.innerHTML = '';
  for (const modId of Object.keys(state.selectedModules)) {
    if (!state.selectedModules[modId]) continue;
    const mod = PRICING_CONFIG.modules[modId];
    const el = document.createElement('div');
    el.className = 'summary-selected-item';
    el.innerHTML = `
      <span class="item-name"><span class="item-check">✓</span>${mod.name}</span>
      <span class="item-price">${fmt(mod.price)}</span>
    `;
    listEl.appendChild(el);
  }
}

/* ============================================
   NUMBER ANIMATION
   ============================================ */

function animateNumber(el, target) {
  const currentText = el.textContent;
  const currentNum = parseInt(currentText.replace(/[^\d]/g, '')) || 0;
  if (currentNum === target) {
    el.textContent = fmt(target);
    return;
  }

  el.classList.add('animating');
  const duration = 300;
  const start = performance.now();

  function tick(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const val = Math.round(currentNum + (target - currentNum) * eased);
    el.textContent = fmt(val);
    if (progress < 1) {
      requestAnimationFrame(tick);
    } else {
      el.classList.remove('animating');
    }
  }

  requestAnimationFrame(tick);
}

/* ============================================
   STEP NAVIGATION
   ============================================ */

function navigateTo(stepNum) {
  const prevStep = state.currentStep;
  if (stepNum === prevStep) return;

  const currentStepEl = document.getElementById('step' + prevStep);
  currentStepEl.style.animation = 'stepOut var(--duration-slow) var(--ease-out)';

  setTimeout(() => {
    currentStepEl.classList.remove('active');
    currentStepEl.style.animation = '';

    const newStepEl = document.getElementById('step' + stepNum);
    newStepEl.classList.add('active');

    state.currentStep = stepNum;
    updateProgress();
    updateSummaryPanel();

    if (stepNum === 3) renderStep3();

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, 250);
}

function updateProgress() {
  const steps = document.querySelectorAll('.progress-step');
  const lines = document.querySelectorAll('.progress-line');

  steps.forEach((s, i) => {
    const n = i + 1;
    s.classList.remove('active', 'done');
    if (n === state.currentStep) s.classList.add('active');
    if (n < state.currentStep) s.classList.add('done');
  });

  lines.forEach((l, i) => {
    if (i + 1 < state.currentStep) l.classList.add('done');
    else l.classList.remove('done');
  });
}

/* ============================================
   STEP 3 RENDERING
   ============================================ */

function renderStep3() {
  const total = calculateTotal();
  document.getElementById('finalTotal').textContent = fmt(total);

  const tbody = document.getElementById('breakdownBody');
  tbody.innerHTML = '';

  for (const modId of Object.keys(state.selectedModules)) {
    if (!state.selectedModules[modId]) continue;
    const mod = PRICING_CONFIG.modules[modId];

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${mod.name}</td>
      <td class="price-cell">${fmt(mod.price)}</td>
      <td>${mod.period}</td>
    `;
    tbody.appendChild(tr);
  }

  const foot = document.getElementById('breakdownFoot');
  foot.innerHTML = `
    <tr class="total-row">
      <td>Итого</td>
      <td class="price-cell">${fmt(total)}</td>
      <td></td>
    </tr>
  `;
}

/* ============================================
   MODULE CARD TOGGLE
   ============================================ */

function toggleModule(moduleId) {
  if (PRICING_CONFIG.modules[moduleId].required) return;

  if (state.selectedModules[moduleId]) {
    delete state.selectedModules[moduleId];
  } else {
    state.selectedModules[moduleId] = true;
  }

  updateCardUI(moduleId);
  updateSummaryPanel();
}

function updateCardUI(moduleId) {
  const card = document.getElementById('card-' + moduleId);
  const checkbox = document.getElementById('mod-' + moduleId);
  if (!card) return;

  if (state.selectedModules[moduleId]) {
    card.classList.add('active');
    if (checkbox) checkbox.checked = true;
  } else {
    card.classList.remove('active');
    if (checkbox) checkbox.checked = false;
  }
}

function handleCardClick(e) {
  const card = e.currentTarget;
  const moduleId = card.dataset.module;
  if (!moduleId) return;
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON' || e.target.tagName === 'LABEL' || e.target.tagName === 'SPAN') return;
  toggleModule(moduleId);
}

/* ============================================
   DETAILS TOGGLE
   ============================================ */

function toggleDetails(e, moduleId) {
  e.stopPropagation();
  const detailsEl = document.getElementById('details-' + moduleId);
  const toggleBtn = e.currentTarget;

  if (detailsEl.classList.contains('open')) {
    detailsEl.classList.remove('open');
    toggleBtn.classList.remove('open');
  } else {
    detailsEl.classList.add('open');
    toggleBtn.classList.add('open');
  }
}

/* ============================================
   FORM VALIDATION & SUBMIT
   ============================================ */

function validateForm() {
  let valid = true;
  const name = document.getElementById('contactName');
  const phone = document.getElementById('contactPhone');
  const messenger = document.getElementById('contactMessenger');

  document.querySelectorAll('.form-error').forEach(e => e.classList.remove('visible'));
  document.querySelectorAll('#contactForm input.error').forEach(e => e.classList.remove('error'));

  if (!name.value.trim()) {
    document.getElementById('error-name').classList.add('visible');
    name.classList.add('error');
    valid = false;
  }

  const phoneClean = phone.value.replace(/[^\d+]/g, '');
  if (phoneClean.length < 11) {
    document.getElementById('error-phone').classList.add('visible');
    phone.classList.add('error');
    valid = false;
  }

  if (!messenger.value.trim()) {
    document.getElementById('error-messenger').classList.add('visible');
    messenger.classList.add('error');
    valid = false;
  }

  return valid;
}

function handleSubmit() {
  if (!validateForm()) return;

  const name = document.getElementById('contactName').value.trim();
  const phone = document.getElementById('contactPhone').value.trim();
  const messenger = document.getElementById('contactMessenger').value.trim();
  const method = document.querySelector('input[name="contactMethod"]:checked').value;
  const methodLabel = method === 'telegram' ? 'Telegram' : 'WhatsApp';

  const selectedModules = [];
  for (const modId of Object.keys(state.selectedModules)) {
    if (state.selectedModules[modId]) {
      const mod = PRICING_CONFIG.modules[modId];
      selectedModules.push(`${mod.name} — ${fmt(mod.price)} ${mod.period}`);
    }
  }

  const total = calculateTotal();
  const message = `📋 Новая заявка с калькулятора цен\n\n` +
    `👤 ${name}\n` +
    `📞 ${phone}\n` +
    `💬 ${methodLabel}: ${messenger}\n\n` +
    `📦 Выбранные услуги:\n${selectedModules.join('\n')}\n\n` +
    `💰 Итого: ${fmt(total)}`;

  // Send to Hermes API
  fetch('/wp-json/aim/v1/price-calculator-lead', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: name,
      phone: phone,
      messenger: messenger,
      method: method,
      modules: selectedModules,
      total: total,
      message: message
    })
  }).then(response => {
    if (response.ok) {
      document.getElementById('contactForm').style.display = 'none';
      document.getElementById('successScreen').classList.add('visible');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      alert('Ошибка отправки. Попробуйте позже или напишите нам напрямую.');
    }
  }).catch(error => {
    console.error('Submit error:', error);
    alert('Ошибка отправки. Попробуйте позже или напишите нам напрямую.');
  });
}

/* ============================================
   PHONE MASK
   ============================================ */

function setupPhoneMask(input) {
  input.addEventListener('input', function(e) {
    let val = input.value.replace(/[^\d+]/g, '');
    if (val.startsWith('8')) val = '+7' + val.slice(1);
    if (val === '+7') val = '+7 ';
    if (!val.startsWith('+7')) val = '+7 ' + val.replace(/^\+?7?/, '');

    let formatted = '+7 (';
    const digits = val.replace(/[^\d]/g, '').slice(1);

    if (digits.length > 0) formatted += digits.slice(0, 3);
    if (digits.length > 3) formatted += ') ' + digits.slice(3, 6);
    if (digits.length > 6) formatted += '-' + digits.slice(6, 8);
    if (digits.length > 8) formatted += '-' + digits.slice(8, 10);

    input.value = formatted;
  });

  input.addEventListener('focus', function() {
    if (!input.value) input.value = '+7 (';
  });

  input.addEventListener('keydown', function(e) {
    if (e.key === 'Backspace' && input.value === '+7 (') {
      e.preventDefault();
    }
  });
}

/* ============================================
   THEME TOGGLE
   ============================================ */

/* ============================================
   INIT
   ============================================ */

function init() {
  document.querySelectorAll('.module-card[data-module]').forEach(card => {
    card.addEventListener('click', handleCardClick);
  });

  document.querySelectorAll('.module-card input[type="checkbox"][id^="mod-"]').forEach(cb => {
    cb.addEventListener('change', function(e) {
      e.stopPropagation();
      const moduleId = cb.id.replace('mod-', '');
      toggleModule(moduleId);
    });
  });

  document.getElementById('toStep2').addEventListener('click', () => navigateTo(2));
  document.getElementById('toStep3').addEventListener('click', () => navigateTo(3));
  document.getElementById('backToStep1').addEventListener('click', () => navigateTo(1));
  document.getElementById('backToStep2').addEventListener('click', () => navigateTo(2));

  document.getElementById('summaryCTA').addEventListener('click', () => navigateTo(3));

  document.getElementById('submitForm').addEventListener('click', handleSubmit);

  document.getElementById('resetAll').addEventListener('click', resetAll);
  document.getElementById('resetFromStep3').addEventListener('click', resetAll);

  setupPhoneMask(document.getElementById('contactPhone'));

  document.getElementById('contactForm').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSubmit();
    }
  });

  // Make progress steps clickable
  document.querySelectorAll('.progress-step').forEach(step => {
    step.style.cursor = 'pointer';
    step.addEventListener('click', function() {
      const stepNum = parseInt(this.getAttribute('data-step'));
      if (stepNum !== state.currentStep) {
        navigateTo(stepNum);
      }
    });
  });

  updateProgress();
  updateSummaryPanel();
}

function resetAll() {
  state.currentStep = 1;
  state.selectedModules = { base: true };

  document.querySelectorAll('.module-card[data-module]').forEach(card => {
    card.classList.remove('active');
    const cb = card.querySelector('input[type="checkbox"]');
    if (cb) cb.checked = false;
  });
  document.getElementById('card-base').classList.add('active');

  document.getElementById('contactForm').style.display = 'block';
  document.getElementById('successScreen').classList.remove('visible');
  document.getElementById('contactName').value = '';
  document.getElementById('contactPhone').value = '';
  document.getElementById('contactMessenger').value = '';
  document.getElementById('methodTelegram').checked = true;
  document.querySelectorAll('.form-error').forEach(e => e.classList.remove('visible'));
  document.querySelectorAll('#contactForm input.error').forEach(e => e.classList.remove('error'));

  document.querySelectorAll('.step').forEach(s => s.classList.remove('active'));
  document.getElementById('step1').classList.add('active');

  updateProgress();
  updateSummaryPanel();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.addEventListener('DOMContentLoaded', init);
</script>

</div>

<?php get_footer(); ?>
