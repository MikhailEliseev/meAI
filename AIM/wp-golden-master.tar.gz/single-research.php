<?php
/**
 * Single: Research (Исследование)
 */
get_header();

while (have_posts()): the_post();
  $research_date = get_post_meta(get_the_ID(), 'research_date', true);
  $company_name = get_post_meta(get_the_ID(), 'company_name', true);
  $company_website = get_post_meta(get_the_ID(), 'company_website', true);
?>

<style>
.research-single{max-width:1000px;margin:0 auto;padding:60px 24px 80px}
.research-single-header{text-align:center;margin-bottom:48px}
.research-single-niches{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-bottom:20px}
.research-single-niche{display:inline-flex;align-items:center;gap:6px;font-family:'Jost',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--accent,#1a1a1a);padding:4px 10px;border-radius:4px;background:var(--surface-2,rgba(0,0,0,.05))}
.research-single-niche::before{content:'';width:5px;height:5px;border-radius:50%;background:var(--accent,#1a1a1a)}
.research-single-title{font-family:'Playfair Display',serif;font-size:clamp(2rem,4vw,3rem);font-weight:400;letter-spacing:-.02em;color:var(--text,#1a1a1a);margin:0 0 16px;line-height:1.2}
.research-single-meta{font-family:'Jost',sans-serif;font-size:.85rem;color:var(--text-secondary,#6b6b6b);display:flex;flex-direction:column;gap:4px;align-items:center}
.research-single-meta-company{font-family:'Jost',sans-serif;font-size:.9rem;font-weight:500;color:var(--text,#1a1a1a)}
.research-single-meta-company a{color:var(--accent,#1a1a1a);text-decoration:none;transition:opacity .2s}
.research-single-meta-company a:hover{opacity:.7}
.research-single-content{font-family:'Jost',sans-serif;font-size:1.05rem;line-height:1.8;color:var(--text,#1a1a1a)}
.research-single-content h2{font-family:'Playfair Display',serif;font-size:1.75rem;font-weight:500;letter-spacing:-.01em;margin:48px 0 16px;color:var(--text,#1a1a1a)}
.research-single-content h3{font-family:'Playfair Display',serif;font-size:1.35rem;font-weight:500;margin:36px 0 12px;color:var(--text,#1a1a1a)}
.research-single-content p{margin:0 0 1.25em}
.research-single-content ul,.research-single-content ol{margin:0 0 1.25em;padding-left:1.5em}
.research-single-content li{margin-bottom:.5em}
.research-single-content blockquote{font-family:'Playfair Display',serif;font-style:italic;font-size:1.15rem;line-height:1.6;color:var(--text,#1a1a1a);border-left:3px solid var(--accent,#1a1a1a);padding:12px 0 12px 24px;margin:32px 0}
.research-single-content strong{font-weight:600}
.research-single-back{display:inline-flex;align-items:center;gap:8px;font-family:'Jost',sans-serif;font-size:.9rem;font-weight:500;color:var(--text-secondary,#6b6b6b);text-decoration:none;margin-bottom:32px;transition:color .2s}
.research-single-back:hover{color:var(--text,#1a1a1a)}
@media(max-width:768px){.research-single{padding:40px 20px 60px}}
</style>

<article class="research-single">
  <a href="/research/" class="research-single-back"><span style="font-family:'Playfair Display',serif;font-size:1.2rem">←</span> Все исследования</a>

  <header class="research-single-header">
    <?php
    $niches = get_the_terms(get_the_ID(), 'research_niche');
    if ($niches && !is_wp_error($niches)): ?>
    <div class="research-single-niches">
      <?php foreach ($niches as $niche): ?>
        <span class="research-single-niche"><?php echo esc_html($niche->name); ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <h1 class="research-single-title"><?php the_title(); ?></h1>

    <div class="research-single-meta">
      <?php if ($research_date): ?>
        <span>Исследование от <?php echo esc_html(date_i18n('d F Y', strtotime($research_date))); ?></span>
      <?php endif; ?>
      <?php if ($company_name): ?>
        <span class="research-single-meta-company">
          Компания:
          <?php if ($company_website): ?>
            <a href="<?php echo esc_url($company_website); ?>" target="_blank" rel="noopener"><?php echo esc_html($company_name); ?></a>
          <?php else: ?>
            <?php echo esc_html($company_name); ?>
          <?php endif; ?>
        </span>
      <?php endif; ?>
    </div>
  </header>

  <div class="research-single-content">
    <?php the_content(); ?>
  </div>
</article>

<?php endwhile; ?>

<?php get_footer(); ?>
