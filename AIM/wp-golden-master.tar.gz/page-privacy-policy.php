<?php
/**
 * Template Name: Privacy Policy
 */

get_header();
?>

<article class="legal-page">
	<a href="/" class="legal-close" aria-label="Закрыть">✕</a>
	<div class="legal-container">
		<?php
		$markdown_file = get_template_directory() . '/docs/legal/privacy-policy.md';
		if (file_exists($markdown_file)) {
			$content = file_get_contents($markdown_file);

			// Split by double newlines to get paragraphs
			$blocks = preg_split('/\n\n+/', $content);

			foreach ($blocks as $block) {
				$block = trim($block);
				if (empty($block)) continue;

				// Headings
				if (preg_match('/^# (.+)$/', $block, $m)) {
					echo '<h1>' . htmlspecialchars($m[1]) . '</h1>';
				} elseif (preg_match('/^## (.+)$/', $block, $m)) {
					echo '<h2>' . htmlspecialchars($m[1]) . '</h2>';
				} elseif (preg_match('/^### (.+)$/', $block, $m)) {
					echo '<h3>' . htmlspecialchars($m[1]) . '</h3>';
				}
				// Lists
				elseif (preg_match('/^[\-\*] /', $block)) {
					echo '<ul>';
					$lines = explode("\n", $block);
					foreach ($lines as $line) {
						if (preg_match('/^[\-\*] (.+)$/', $line, $m)) {
							$text = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $m[1]);
							echo '<li>' . $text . '</li>';
						}
					}
					echo '</ul>';
				}
				// Regular paragraph
				else {
					$text = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $block);
					$text = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $text);
					// Handle single line breaks within paragraph
					$text = str_replace("\n", ' ', $text);
					echo '<p>' . $text . '</p>';
				}
			}
		} else {
			echo '<p>Документ не найден.</p>';
		}
		?>

		<div class="legal-back">
			<a href="/" class="btn-back">← Вернуться на главную</a>
		</div>
	</div>
</article>

<style>
.legal-page {
	max-width: 900px;
	margin: 0 auto;
	padding: 80px 24px 120px;
	position: relative;
}
.legal-close {
	position: fixed;
	top: 24px;
	right: 24px;
	width: 44px;
	height: 44px;
	display: flex;
	align-items: center;
	justify-content: center;
	background: var(--surface, #ffffff);
	border: 1px solid var(--border, rgba(0,0,0,.08));
	border-radius: 50%;
	font-size: 24px;
	color: var(--text, #1a1a1a);
	text-decoration: none;
	cursor: pointer;
	transition: all .2s ease;
	box-shadow: 0 2px 8px rgba(0,0,0,.1);
	z-index: 1000;
}
.legal-close:hover {
	transform: scale(1.1);
	box-shadow: 0 4px 12px rgba(0,0,0,.15);
}
.legal-container {
	background: var(--surface, #ffffff);
	border: 1px solid var(--border, rgba(0,0,0,.08));
	border-radius: 8px;
	padding: 48px;
	box-shadow: 0 2px 8px rgba(0,0,0,.04);
}
.legal-container h1 {
	font-family: 'Playfair Display', serif;
	font-size: 2.5rem;
	font-weight: 600;
	color: var(--text, #1a1a1a);
	margin: 0 0 32px;
	line-height: 1.2;
}
.legal-container h2 {
	font-family: 'Jost', sans-serif;
	font-size: 1.5rem;
	font-weight: 600;
	color: var(--text, #1a1a1a);
	margin: 40px 0 16px;
	line-height: 1.3;
}
.legal-container h3 {
	font-family: 'Jost', sans-serif;
	font-size: 1.2rem;
	font-weight: 600;
	color: var(--text, #1a1a1a);
	margin: 32px 0 12px;
	line-height: 1.4;
}
.legal-container p, .legal-container li {
	font-family: 'Jost', sans-serif;
	font-size: 1rem;
	color: var(--text-secondary, #4a4a4a);
	line-height: 1.7;
	margin: 0 0 16px;
}
.legal-container ul {
	margin: 0 0 16px;
	padding-left: 24px;
}
.legal-container strong {
	color: var(--text, #1a1a1a);
	font-weight: 600;
}
.legal-back {
	margin-top: 48px;
	padding-top: 32px;
	border-top: 1px solid var(--border, rgba(0,0,0,.08));
	text-align: center;
}
.btn-back {
	display: inline-block;
	padding: 12px 32px;
	background: var(--accent, #1a1a1a);
	color: white;
	font-family: 'Jost', sans-serif;
	font-size: .95rem;
	font-weight: 500;
	text-decoration: none;
	border-radius: 6px;
	transition: opacity .2s;
}
.btn-back:hover {
	opacity: .85;
}

[data-theme="dark"] .legal-close {
	background: var(--surface, #1a1a1a);
	border-color: var(--border, rgba(255,255,255,.1));
	color: var(--text, #f5f0e8);
	box-shadow: 0 2px 8px rgba(0,0,0,.3);
}
[data-theme="dark"] .legal-container {
	background: var(--surface, #1a1a1a);
	border-color: var(--border, rgba(255,255,255,.1));
	box-shadow: 0 2px 8px rgba(0,0,0,.2);
}
[data-theme="dark"] .legal-container h1,
[data-theme="dark"] .legal-container h2,
[data-theme="dark"] .legal-container h3,
[data-theme="dark"] .legal-container strong {
	color: var(--text, #f5f0e8);
}
[data-theme="dark"] .legal-container p,
[data-theme="dark"] .legal-container li {
	color: var(--text-secondary, #b8b8b8);
}

@media (max-width: 768px) {
	.legal-page { padding: 60px 20px 80px; }
	.legal-container { padding: 32px 24px; }
	.legal-container h1 { font-size: 2rem; margin-bottom: 24px; }
	.legal-container h2 { font-size: 1.3rem; margin-top: 32px; }
	.legal-container h3 { font-size: 1.1rem; margin-top: 24px; }
}
</style>

<?php get_footer(); ?>
