<?php
/**
 * Archive: Research (Исследования)
 * Lists all published research posts.
 */
get_header();
?>

<style>
.research-hero{text-align:center;padding:80px 24px 64px;max-width:800px;margin:0 auto}
.research-hero-title{font-family:'Playfair Display',serif;font-size:clamp(2.5rem,5vw,4rem);font-weight:400;letter-spacing:-.02em;color:var(--text,#1a1a1a);margin:0 0 16px;line-height:1.15}
.research-hero-subtitle{font-family:'Jost',sans-serif;font-size:1.1rem;color:var(--text-secondary,#6b6b6b);font-weight:400;line-height:1.6;max-width:560px;margin:0 auto}
.research-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:1px;max-width:1200px;margin:0 auto 80px;padding:0 24px;background:var(--border,rgba(0,0,0,.08))}
.research-card{background:var(--surface,#fff);padding:36px 32px;display:flex;flex-direction:column;gap:14px;transition:all .3s cubic-bezier(.16,1,.3,1);position:relative;overflow:hidden}
.research-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--accent,#1a1a1a);transform:scaleX(0);transform-origin:left;transition:transform .35s cubic-bezier(.16,1,.3,1)}
.research-card:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(0,0,0,.06)}
.research-card:hover::before{transform:scaleX(1)}
.research-card-niches{display:flex;flex-wrap:wrap;gap:6px}
.research-card-niche{display:inline-flex;align-items:center;gap:5px;font-family:'Jost',sans-serif;font-size:.7rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--accent,#1a1a1a);padding:3px 8px;border-radius:4px;background:var(--surface-2,rgba(0,0,0,.05))}
.research-card-niche::before{content:'';width:4px;height:4px;border-radius:50%;background:var(--accent,#1a1a1a);flex-shrink:0}
.research-card-meta{font-family:'Jost',sans-serif;font-size:.75rem;font-weight:500;letter-spacing:.08em;text-transform:uppercase;color:var(--text-secondary,#6b6b6b);display:flex;flex-direction:column;gap:4px}
.research-card-company{font-family:'Jost',sans-serif;font-size:.8rem;font-weight:500;color:var(--text,#1a1a1a)}
.research-card-title{font-family:'Playfair Display',serif;font-size:1.5rem;font-weight:500;line-height:1.3;color:var(--text,#1a1a1a);margin:0;letter-spacing:-.01em}
.research-card-title a{color:inherit;text-decoration:none;transition:color .2s}
.research-card-title a:hover{color:var(--accent,#1a1a1a)}
.research-card-excerpt{font-family:'Jost',sans-serif;font-size:.95rem;line-height:1.7;color:var(--text-secondary,#6b6b6b);margin:0;flex:1}
.research-card-read-more{display:inline-flex;align-items:center;gap:8px;font-family:'Jost',sans-serif;font-size:.85rem;font-weight:500;color:var(--text,#1a1a1a);text-decoration:none;transition:gap .25s cubic-bezier(.16,1,.3,1);align-self:flex-start}
.research-card-read-more:hover{gap:14px}
.research-card-read-more-arrow{font-family:'Playfair Display',serif;font-size:1.1rem;transition:transform .25s cubic-bezier(.16,1,.3,1)}
.research-card-read-more:hover .research-card-read-more-arrow{transform:translateX(3px)}
.research-empty{text-align:center;padding:80px 24px;font-family:'Jost',sans-serif;color:var(--text-secondary,#6b6b6b)}
[data-theme="dark"] .research-card{background:var(--surface,#1a1a1a);backdrop-filter:blur(12px) saturate(1.4);border:1px solid rgba(201,169,110,.08)}
[data-theme="dark"] .research-card::before{background:var(--accent,#c9a96e)}
[data-theme="dark"] .research-card:hover{box-shadow:0 8px 32px rgba(0,0,0,.3);border-color:rgba(201,169,110,.2)}
[data-theme="dark"] .research-grid{background:rgba(201,169,110,.08)}
@media(max-width:768px){.research-hero{padding:48px 20px 40px}.research-grid{grid-template-columns:1fr;padding:0 16px}.research-card{padding:28px 24px}}
</style>

<section class="research-hero">
  <h1 class="research-hero-title">Исследования</h1>
  <p class="research-hero-subtitle">Аналитические разборы компаний, рынков и медицинских бизнесов. Данные, цифры, выводы — без воды.</p>
</section>

<?php if (have_posts()): ?>
<div class="research-grid">
  <?php while (have_posts()): the_post(); ?>
    <article class="research-card">
      <?php
      $niches = get_the_terms(get_the_ID(), 'research_niche');
      if ($niches && !is_wp_error($niches)): ?>
      <div class="research-card-niches">
        <?php foreach ($niches as $niche): ?>
          <span class="research-card-niche"><?php echo esc_html($niche->name); ?></span>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <div class="research-card-meta">
        <?php
        $research_date = get_post_meta(get_the_ID(), 'research_date', true);
        $company_name = get_post_meta(get_the_ID(), 'company_name', true);
        ?>
        <?php if ($research_date): ?>
          <span>Исследование от <?php echo esc_html(date_i18n('d F Y', strtotime($research_date))); ?></span>
        <?php endif; ?>
        <?php if ($company_name): ?>
          <span class="research-card-company"><?php echo esc_html($company_name); ?></span>
        <?php endif; ?>
      </div>

      <h2 class="research-card-title">
        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
      </h2>

      <p class="research-card-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 35, '…')); ?></p>

      <a href="<?php the_permalink(); ?>" class="research-card-read-more">
        Читать <span class="research-card-read-more-arrow">→</span>
      </a>
    </article>
  <?php endwhile; ?>
</div>
<?php else: ?>
  <div class="research-empty">
    <p>Исследования пока не опубликованы.</p>
    <p>Скоро здесь появятся аналитические разборы медицинских бизнесов.</p>
  </div>
<?php endif; ?>

<?php get_footer(); ?>
